clc;
clear;
close all;

%%  %%%%%%%%%%%%%%%%%%%%%%%%% Introduction %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% This file generates data files for ADAPTIC with multiple partitions
% and hierachical arrangement

%%  %%%%%%%%%%%%%%%%%%% Define type of modification %%%%%%%%%%%%%%%%%%%%%%%

file_name_p = 'Example';  % No need to specify file type, i.e. '.dat'

%%  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Input %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%========================================================================

% Input general description of the data file (common to child and parent
% file)

DESCRIPTION.Aim='Example data file used to validate this code';
DESCRIPTION.Prob = 'Fill in problem description';
DESCRIPTION.Mesh = 'Fill in element types, sizes and characteristics';
DESCRIPTION.Mat = 'Fill in type of material model';
DESCRIPTION.Trace = 'Fill in tracing strategy, static/dynamic?';
dt = datetime('today');
DESCRIPTION.FileModDate = datestr(dt,'dd/mm/yyyy');

%========================================================================

% Input type of analysis (Common to all partition files)
Type_ana_text = '3d.continuum dynamics';

%========================================================================
% Input material properties
MAT.N = 1;   % Number of materials used in analysis

% Material 1
MAT.Mat1.name = 'mat1';
MAT.Mat1.model = 'beth';
MAT.Mat1.properties = '1e3 0.3 0';

%========================================================================
% Input group properties
GRP.N = 1;  % Number of groups in total

% Group 1
GRP.Grp1.type = 'wd06';
GRP.Grp1.name = 'gp1';
GRP.Grp1.mat = 'mat1';
GRP.Grp1.prop_name = 'mat.name    gauss.points    density';
GRP.Grp1.prop_val = 'mat1    6    8e-9 ';
GRP.Grp1.nod_num = 6;    % Required node number

%========================================================================
% Input nodal coordinates and element connectivity (either by manual input 
% or from external sources such as Gmsh or Abaqus, the nodal coordinates 
% should be input in form of 2D array with four columns)

% For nodal coordinates: following fields must be provided
% Coord: 4 columns with id, x,y,z coordinates
% Coord_ad: Any other additional nodes

% For element connectivity: following fields must be provided for each
% group
% grp: corresponding group name
% Nelm: number of element
% Conn: element ID, Node ID being connected

% For partition information: following fields must be provided for each
% partition
% nodID: ID of nodes belonging to each partition
% elm:   ID of elements belonging to each partition

% Group 1

% Input option 1: from predefined text file (e.g. from ABAQUS)
% Nodal coordinate
NODE.Coord = load('nodal coordinate.txt'); 

% Any additional nodes
NODE.Coord_ad = [30000, 0, -0.5, 0];
NODE.adflag = 0;        % 0: no additional nodes; 1: additional node required

% Element connectivity
ELEMENT.Grp1.Conn = load('element conn.txt');    
ELEMENT.Grp1.Nelm = length(ELEMENT.Grp1.Conn);
ELEMENT.Grp1.grp = GRP.Grp1.name;

% Input partition information (From Gmsh as an example)
PARTITION = Gmshread('Example_Gmsh.dat',NODE.Coord,ELEMENT.Grp1.Conn); % Nodal coordinate

% Input option 2: Manual input with intrinsic incrementation syntax in
% ADAPTIC, in this case the element and node struct are named as 'NODE_INC'
% and 'ELEMENT_INC', same applied to all other quantities.

%========================================================================

% Input partition information stored in a struct HIERACICAL

HIERACHICAL.level = 1;

% Level 0 partitioning
HIERACHICAL.lv0.N = 1;   % Number of level 0 parent partitions
HIERACHICAL.lv0.PartID = cell(HIERACHICAL.lv0.N,1);  % Records how individual partitions are grouped as a sub-parent partition
HIERACHICAL.lv0.PartID{1,1} = 1:2;


% Level 1 partitioning
HIERACHICAL.lv1.N = 2;   % Parent partition number for level 1
HIERACHICAL.lv1.PartID = cell(HIERACHICAL.lv1.N,1);  % Records how individual partitions are grouped as a sub-parent partition

% As an example, assume the domain is split into 8 subdomains and domain
% 1-4 and 5-8 are grouped under two level 1 partent partitions

HIERACHICAL.lv1.PartID{1,1} = [1,2,3,4];
HIERACHICAL.lv1.PartID{2,1} = [5,6,7,8];

%========================================================================

% Input restraint group properties
RES.N = 2;  % Number of groups in total

% Group 1

% Example: restrain y-displacement at nodes along line y=-50
RES.Grp1.dir = 'y';
index_res = find(NODE.Coord(:,3) == -50);
RES.Grp1.node = NODE.Coord(index_res,1);
RES.Grp1.spec_method = 1;   % 1: node list, 2: incrementation, 3:mixed

% Group 2

% Example: restrain z-displacement at all nodes (automatic incrementation from 1 to the end of node index) 
RES.Grp2.dir= 'z';
RES.Grp2.num_inc = 1;
RES.Grp2.node_inc1= [1 0;1 length(NODE.Coord)-1];

%             Array             ADAPTIC notation
% ----------------------------------------------------
% node_inc1: [a    0        |     f    a
%             b    c]       |     r    b    c

RES.Grp2.spec_method = 2;   % 1: node list, 2: incrementation, 3:mixed

%========================================================================

% Input integration scheme parameter (note Newmark by default)
INTSCHEME.scheme = 'hilber';
INTSCHEME.para_N = 1;  % Number of parameter
INTSCHEME.para_name = strings(1);
INTSCHEME.para_name(1) = 'alpha';
INTSCHEME.para_val = -0.333;

% Semi-explicit scheme
% INTSCHEME.scheme = 'newmark';
% INTSCHEME.para_N = 2;  % Number of parameter
% INTSCHEME.para_name = strings(2);
% INTSCHEME.para_name(1) = 'beta';
% INTSCHEME.para_name(2) = 'gamma';
% INTSCHEME.para_val = [0.25 0.5];

%========================================================================

% Input loading curve (Assume only one curve, more curves can be added by
% adding more groups)
CURVE.flag = 1;    % 1: curve is required; 0: curve is not required
CURVE.start_time = '0';
CURVE.name = 'c1';
CURVE.xypoints = [200 1];   % Points in time-load factor space to define the curve

%========================================================================

% Input loading group 

LOAD.N = 2;

% Group1
LOAD.Grp1.name = 'initial.loads';
LOAD.Grp1.dir = 'x';
LOAD.Grp1.type = 'v';
LOAD.Grp1.value = '100';
index_res = find(NODE.Coord(:,2) == -50 & NODE.Coord(:,3) < -25);
LOAD.Grp1.node = NODE.Coord(index_res,1);
LOAD.Grp1.spec_method = 1;   % 1: node list, 2: incrementation, 3:mixed

% Group2
LOAD.Grp2 = LOAD.Grp1;
LOAD.Grp2.name = 'dynamic.loads';
LOAD.Grp2.type = 'a';
LOAD.Grp2.value = '0';
LOAD.Grp2.crv = 'c1';

%========================================================================

% Input equilibrium stage
EQUI.xypoints = [100  100];

%========================================================================

% Input solution of equations
SOLVER.type = 'parallel.mumps';
SOLVER.type_parent = 'mumps';

%========================================================================

% Input iterative strategy
ITERSTRAT.number = '10';    % Number of maximum iteration allowed
ITERSTRAT.reform = '10';    % Number of iterations allowed to recalculate tangent stiffness
ITERSTRAT.reduction = '10';    % Number of substeps created when convergence issue
ITERSTRAT.div = '10';    % Number of iterations to check divergence
ITERSTRAT.maxconv = '1e7';    % tolerance to be classified as divergence

%========================================================================

% Input convergence criteria
CONV.tol = '1e-4';    % tolerance
CONV.ref_type = 'w';    % 'w': work reference; 'fm' force & moment refernce
CONV.ref1 = '1e5';    % Number of iterations allowed to recalculate tangent stiffness
CONV.ref2 = '1e5';    % Number of iterations allowed to recalculate tangent stiffness

%========================================================================

% Input output frequency
OUTPUT.freq = '5 stress';

%========================================================================
% End of input stage

%%  %%%%%%%%%%%%%%%%%%%%%% Partition_process stage %%%%%%%%%%%%%%%%%%%%%%%%
% This section splits above information into each partition
% stored in struct PARTITION

%========================================================================

% Fields that need to be separated contains: material, group, nodes,
% elements, restraint and loading. The remaining fields are established at
% the end of this stage.

% Firstly identify which nodes appear on the boundary between partitions

NodePartCounter = zeros(length(NODE.Coord),2);
NodePartCounter(:,1) = NODE.Coord(:,1);

for i = 1:PARTITION.General.N
   NodePartCounter(PARTITION.(['Part' num2str(i)]).nodID,2) = NodePartCounter(PARTITION.(['Part' num2str(i)]).nodID,2) + 1;
end
NodePartCounter(NodePartCounter(:,2) == 1,:) = [];

% Then identify the nodes in each partition that belong to the boundary,
% for phase field also identify their index in the element connectivity and
% corresponding element

for i = 1:PARTITION.General.N
   PARTITION.(['Part' num2str(i)]).nodID_boundary = NodePartCounter(ismember(NodePartCounter(:,1),PARTITION.(['Part' num2str(i)]).nodID),1);

   % Comment following codes out for stadnard displacement analysis

   %=======================================================================

   % For additional freedoms:
   % 1st column records node number, 2nd column records the element the dof belongs to, the 3rd column
   % records the index of dof in that element, note repeated node is not
   % required, so the final number should be same as the node number on the
   % boundary considering standard elements

   PARTITION.(['Part' num2str(i)]).dofAD_boundary = zeros(1,3);   
   elm_conn = ELEMENT.Grp1.Conn(PARTITION.(['Part' num2str(i)]).elm,:);
   for j = 2:size(ELEMENT.Grp1.Conn,2)

       % Check which nodes on the boundary are belonging to which element
       % Firstly find all nodes on boundary appearing in current position
       dofAD_state = ismember(elm_conn(:,j),PARTITION.(['Part' num2str(i)]).nodID_boundary);
       x = length(elm_conn(dofAD_state,1));
       PARTITION.(['Part' num2str(i)]).dofAD_boundary(end+1:end+x,:) = sortrows([elm_conn(dofAD_state==1,j) elm_conn(dofAD_state==1,1) ones(x,1)*(j-1)]);
     
   end
   
   % Eliminate repeated nodes/dof in first column
   PARTITION.(['Part' num2str(i)]).dofAD_boundary = PARTITION.(['Part' num2str(i)]).dofAD_boundary(2:end,:);
   [nodID_unique,index_unique] = unique(PARTITION.(['Part' num2str(i)]).dofAD_boundary(:,1),'first');
   PARTITION.(['Part' num2str(i)]).dofAD_boundary =  PARTITION.(['Part' num2str(i)]).dofAD_boundary(index_unique,:);

   %=======================================================================
end

% Assume all groups and materials are contained in each partition,
% this may lead to spurious definition in some cases

for i = 1:PARTITION.General.N
   PARTITION.(['Part' num2str(i)]).mat = MAT;
   PARTITION.(['Part' num2str(i)]).grp = GRP;
   PARTITION.(['Part' num2str(i)]).grp.N = PARTITION.(['Part' num2str(i)]).grp.N;
   
   PARTITION.(['Part' num2str(i)]).node.Coord = NODE.Coord(sort(PARTITION.(['Part' num2str(i)]).nodID),:);
   PARTITION.(['Part' num2str(i)]).element.Grp1 = ELEMENT.Grp1;
   PARTITION.(['Part' num2str(i)]).element.Grp1.Conn = ELEMENT.Grp1.Conn(PARTITION.(['Part' num2str(i)]).elm,:);
   PARTITION.(['Part' num2str(i)]).element.Grp1.Nelm = size(PARTITION.(['Part' num2str(i)]).element.Grp1.Conn,1);
   
   % No coupling
   PARTITION.(['Part' num2str(i)]).node.adflag = 0;
   PARTITION.(['Part' num2str(i)]).res.N = 0;
       
end


% For each partition,identify restraints and loading
% if load/restraint are created using incrementation then need to convert
% it into equivalent node list. For now since only second restraint group
% are defined in this way, it is converted into equivalent array
% explicitly

RES.Grp2.node = 1:RES.Grp2.node_inc1(2,2)+1;

for i = 1:PARTITION.General.N

   % Create a flag indicating number of loading group of current partition
   PARTITION.(['Part' num2str(i)]).load.N = 0;

   
   % Loop over all the loading group
   for j = 1:LOAD.N
       
       % Eliminate nodes on the boundary
       index_load = intersect(PARTITION.(['Part' num2str(i)]).nodID,LOAD.(['Grp' num2str(j)]).node);
       index_load=setdiff(index_load,PARTITION.(['Part' num2str(i)]).nodID_boundary);
       
       if ~isempty(index_load)
           PARTITION.(['Part' num2str(i)]).load.N = PARTITION.(['Part' num2str(i)]).load.N+1;
           x = PARTITION.(['Part' num2str(i)]).load.N;
           PARTITION.(['Part' num2str(i)]).load.(['Grp' num2str(x)]) = LOAD.(['Grp' num2str(j)]);
           PARTITION.(['Part' num2str(i)]).load.(['Grp' num2str(x)]).node = index_load;

           % Create curve information
           PARTITION.(['Part' num2str(i)]).curve = CURVE;
           
       else
           PARTITION.(['Part' num2str(i)]).curve.flag = 0;
       end
  
   end
   
   % Restriant information
   % Loop over all the restraint group
   for j = 1:RES.N
       
       % Eliminate nodes on the boundary
       index_res = intersect(PARTITION.(['Part' num2str(i)]).nodID,RES.(['Grp' num2str(j)]).node);
       index_res=setdiff(index_res,PARTITION.(['Part' num2str(i)]).nodID_boundary);
       
       if ~isempty(index_res)
           PARTITION.(['Part' num2str(i)]).res.N = PARTITION.(['Part' num2str(i)]).res.N+1;
           PARTITION.(['Part' num2str(i)]).res.(['Grp' num2str(PARTITION.(['Part' num2str(i)]).res.N)]) = RES.(['Grp' num2str(j)]);
           PARTITION.(['Part' num2str(i)]).res.(['Grp' num2str(PARTITION.(['Part' num2str(i)]).res.N)]).node = index_res;
           PARTITION.(['Part' num2str(i)]).res.(['Grp' num2str(PARTITION.(['Part' num2str(i)]).res.N)]).spec_method = 1;
           
       end
  
   end
       
end

% End of child partition information

%========================================================================

% Create Parent partition information(Node, element, additional freedom,
% group, restraint and loading needs to be sepcified)
% Node information
PARTITION.Parent.node.Coord = NODE.Coord(NodePartCounter(:,1),:);

% Group information
% Create 1 super element group for each partition with differnt number of
% boundary nodes
PARTITION.Parent.grp.N = 0;
PARTITION.General.Supelm.node_num = [];

for i = 1:PARTITION.General.N

    if (~ismember(length(PARTITION.(['Part' num2str(i)]).nodID_boundary),PARTITION.General.Supelm.node_num)) 
      PARTITION.Parent.grp.N = PARTITION.Parent.grp.N+1;     
      PARTITION.General.Supelm.node_num(end+1,:) = length(PARTITION.(['Part' num2str(i)]).nodID_boundary);
    end
end

for i = 1:PARTITION.Parent.grp.N
    PARTITION.Parent.grp.(['Grp' num2str(i)]).type = 'part';
    PARTITION.Parent.grp.(['Grp' num2str(i)]).name = ['gpp' num2str(i)];
    PARTITION.Parent.grp.(['Grp' num2str(i)]).prop_name = 'nodes      element.freedoms';
    PARTITION.Parent.grp.(['Grp' num2str(i)]).node = num2str(PARTITION.General.Supelm.node_num(i));
    PARTITION.Parent.grp.(['Grp' num2str(i)]).elmdof = num2str(PARTITION.General.Supelm.node_num(i));
    PARTITION.Parent.grp.(['Grp' num2str(i)]).node_num = PARTITION.General.Supelm.node_num(i);
    x = num2str(PARTITION.General.Supelm.node_num(i));
    PARTITION.Parent.grp.(['Grp' num2str(i)]).prop_val = [num2str(x) '         ' num2str(x)];
   
    % Element
    PARTITION.Parent.element.(['Grp' num2str(i)]).Conn = zeros(1,PARTITION.Parent.grp.(['Grp' num2str(i)]).node_num+1);
end

% Create element connectivity
j = 0;
for i = 1:PARTITION.General.N
    % Check which superelement that current partition belongs to 
    x = find(PARTITION.General.Supelm.node_num == length(PARTITION.(['Part' num2str(i)]).nodID_boundary)); 
    j = j+1;
    PARTITION.Parent.element.(['Grp' num2str(x)]).Conn(end+1,:) = [j PARTITION.(['Part' num2str(i)]).nodID_boundary'];
end

for i = 1:PARTITION.Parent.grp.N
    PARTITION.Parent.element.(['Grp' num2str(i)]).Conn = PARTITION.Parent.element.(['Grp' num2str(i)]).Conn(2:end,:);
    PARTITION.Parent.element.(['Grp' num2str(i)]).Nelm = size(PARTITION.Parent.element.(['Grp' num2str(i)]).Conn,1); 
end

PARTITION.Parent.node.adflag = 0;
PARTITION.Parent.res.N = 0;


% Additional freedom: need to determine which dofs are shared between which
% two partitions and their locations as recorded in each child part
% dofAD_boundary

% for each node on the boundary, find which partition they belong to and
% their index in the additional dof list defined in child partition
% Create a mapping
NodePartGroup = false(1,PARTITION.General.N);
PARTITION.Parent.dofAD_couple = cell(1,2);
PARTITION.Parent.dofAD_couple{1} = zeros(1,2);
% First cell stores partition coupling information while second cell stores
% dof coupling information

% Populate the mapping
for i = 1:size(NodePartCounter,1)
    for j = 1:PARTITION.General.N
       NodePartGroup(1, j) = ismember(NodePartCounter(i,1), PARTITION.(['Part' num2str(j)]).nodID_boundary);
    end
    
    % For all possible combination of partitions, coupling corresponding
    % dofs.
    % Find the first child partition containing the node/dof
    elm = find(NodePartGroup);
    elm1 = elm(1);
    for j = 1:sum(NodePartGroup)-1
        elm2 = elm(j+1);  
        % If a node is connected to N partitions, then it always requires N-1 coupling,
        % Always coupling with first element to avoid confused coupling
        
        % Check if current partition combination has been established in
        % cell
        if ismember([elm1 elm2],PARTITION.Parent.dofAD_couple{1},'rows')
           matchingRows = ismember(PARTITION.Parent.dofAD_couple{1}, [elm1 elm2], 'rows');
           x = find(matchingRows)-1;
           index1 = find(PARTITION.(['Part' num2str(elm1)]).nodID_boundary==NodePartCounter(i,1));
           index2 = find(PARTITION.(['Part' num2str(elm2)]).nodID_boundary==NodePartCounter(i,1));
           PARTITION.Parent.dofAD_couple{2}{x,1}(end+1) = index1;
           PARTITION.Parent.dofAD_couple{2}{x,2}(end+1) = index2;
           
        else
           PARTITION.Parent.dofAD_couple{1}(end+1,:) = [elm1 elm2];
           
           % Find corresponding position of the node in corresponding
           % partition
           index1 = find(PARTITION.(['Part' num2str(elm1)]).nodID_boundary==NodePartCounter(i,1));
           index2 = find(PARTITION.(['Part' num2str(elm2)]).nodID_boundary==NodePartCounter(i,1));
           PARTITION.Parent.dofAD_couple{2}{end+1,1} = index1;
           PARTITION.Parent.dofAD_couple{2}{end,2} = index2;
        end
    end
    
end
PARTITION.Parent.dofAD_couple{1} = PARTITION.Parent.dofAD_couple{1}(2:end,:);


% Restraints and loading
PARTITION.Parent.load.N = 0;
% Loop over all the loading group
for j = 1:LOAD.N
    
    % Eliminate nodes on the boundary
    index_load = intersect(PARTITION.Parent.node.Coord(:,1),LOAD.(['Grp' num2str(j)]).node);
    
    if ~isempty(index_load)
        PARTITION.Parent.load.N = PARTITION.Parent.load.N+1;
        PARTITION.Parent.load.(['Grp' num2str(PARTITION.Parent.load.N)]) = LOAD.(['Grp' num2str(j)]);
        PARTITION.Parent.load.(['Grp' num2str(PARTITION.Parent.load.N)]).node = index_load;
        
        % Create curve information
        PARTITION.Parent.curve = CURVE;
        
    else
        PARTITION.Parent.curve.flag = 0;
    end
    
end

% Restriant information
% Loop over all the restraint group
for j = 1:RES.N
    
    % Eliminate nodes on the boundary
    index_res = intersect(PARTITION.Parent.node.Coord(:,1),RES.(['Grp' num2str(j)]).node);
    
    if ~isempty(index_res)
        PARTITION.Parent.res.N = PARTITION.Parent.res.N+1;
        PARTITION.Parent.res.(['Grp' num2str(PARTITION.Parent.res.N)]) = RES.(['Grp' num2str(j)]);
        PARTITION.Parent.res.(['Grp' num2str(PARTITION.Parent.res.N)]).node = index_res;
        PARTITION.Parent.res.(['Grp' num2str(PARTITION.Parent.res.N)]).spec_method = 1;
        
    end
    
end
       

% Some fields only need to be established once in the parent file
% Equilibrium stage
PARTITION.Parent.equi = EQUI;

% Iterative strategy
PARTITION.Parent.iterstrat = ITERSTRAT;

%========================================================================

% Establish general information, including
% Description;type of analysis;integration scheme;solver type;
% Convergence criteria; output frequency
% Description
PARTITION.General.description = DESCRIPTION;

% Type of analysis
PARTITION.General.Type_ana_text = Type_ana_text;

% Integration scheme
PARTITION.General.intscheme = INTSCHEME;

% Solver type
PARTITION.General.solver = SOLVER;

% Convergence criteria
PARTITION.General.conv = CONV;

% Output
PARTITION.General.output = OUTPUT;

% End
%========================================================================

%%  %%%%%%%%%%%%% Partition_process stage (hierachical) %%%%%%%%%%%%%%%%%%%
% regroup the partition information in a new struct if there is hierachical
% partitioning modelling, note intermediate level only contains parent
% element and there should not be any change to individual part loading and
% restraint since they should only be set to be applied to nodes that are
% not on boundary. 

% *Explanation of fields in hierachical partitioning
% rank: number increased monotonically for each parent and child partition
% within the tree structure
% ID: for each level other than the base level, the ID would start from 1
% and increase monotonically for each parent at current level, for base
% level, ID tells about the current paritition ID in the originally
% individually partitioned case
% level: levels of partition in the tree structure

if HIERACHICAL.level ~= 0
    PARTITION_H.General = PARTITION.General;
    PARTITION_H.level = 0;PARTITION_H.rank = 0;PARTITION_H.ID = 0;
    PARTITION_H = Hierachical_Assemble(PARTITION,PARTITION_H,HIERACHICAL,0,1);
    PARTITION_H = Hierachical_FormParent(PARTITION,PARTITION_H,HIERACHICAL,0);
    PARTITION_H = Hierachical_FormRL(PARTITION,PARTITION_H,HIERACHICAL,0);
end

%% Mesh information analysis
% Total number of nodes
fprintf('Total number of nodes: %g; \n', length(NODE.Coord));

% Nodes in parent partition
fprintf('Number of nodes in parent partition: %g; \n', length(PARTITION.Parent.node.Coord));

% Average nodes in child partition
sum = 0;
max_nod = -inf;
for i = 1:PARTITION.General.N
    % Check current partition belong to which superelement
    sum = sum+length(PARTITION.(['Part' num2str(i)]).nodID_boundary);
    max_nod = max(max_nod,length(PARTITION.(['Part' num2str(i)]).nodID_boundary));
end

fprintf('Number of internal nodes in child partition: %g; \n', length(NODE.Coord)-length(PARTITION.Parent.node.Coord));

% Average and maximum number of nodes in superelement
fprintf('Average number of nodes in super-element: %g \n', sum/PARTITION.General.N)
fprintf('Maximum number of nodes in super-element: %g \n', max_nod)

% Average number of nodes in level 0 parent partition
if HIERACHICAL.level ~= 0
    fprintf('Number of nodes in level 0 parent partititon: %g \n', length(PARTITION_H.Parent.node.Coord));
end

%% Writing stage
% Call writing function for parent and child partitions

if HIERACHICAL.level == 0
    DatFileWrite_partition(PARTITION,'Parent', [file_name_p '.dat']);
    for i = 1:PARTITION.General.N
        DatFileWrite_partition(PARTITION,'Child',[file_name_p '#' sprintf('%03d', i) '.dat'],i);
    end
else
    recursive_DatWrite(PARTITION_H,HIERACHICAL,file_name_p)
end

%%       
function fileID = recursive_DatWrite(PARTITION_H,HIERACHICAL,file_name_p,fileID,level)
    % This nested function writes data file for hierachical partitioning
    % via recursion

    % This is when the function is first called
    if nargin == 3
        fileID = 0;
        level = 0;
        file_name_parent = [file_name_p '.dat'];
    else
        fileID = fileID+1;
        file_name_parent = [file_name_p '#' sprintf('%03d',fileID) '.dat'];
    end
    PARTITION_H.rank = fileID;
    DatFileWrite_partition_H(PARTITION_H,'Parent', file_name_parent);

    for i = 1:PARTITION_H.N_subpart
        PARTITION_H.(['Part' num2str(i)]).Parent_rank = PARTITION_H.rank;
        if level < HIERACHICAL.level
            fileID = recursive_DatWrite(PARTITION_H.(['Part' num2str(i)]),HIERACHICAL,file_name_p,fileID,level+1);
        else
            fileID = fileID+1;
            PARTITION_H.(['Part' num2str(i)]).rank = fileID;
            DatFileWrite_partition_H(PARTITION_H,'Child',[file_name_p '#' sprintf('%03d', fileID) '.dat'],i);
        end
       
    end
end