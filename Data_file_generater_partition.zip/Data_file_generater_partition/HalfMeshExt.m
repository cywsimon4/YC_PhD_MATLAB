function [Node_coord_fin,elm_conn_fin,PARTITION] = HalfMeshExt(Node_coord_half,elm_conn_half,option,PARTITION)

%%%%%%%%%%%%%%%%%%%%%%%%%%% Introduction %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This is the MATLAB file for generating the full size mesh from any
% arbitrary half mesh model symmetric about x axis (y=0)

%%%%%%%%%%%%%%%%%%%%%% Initialisation and input %%%%%%%%%%%%%%%%%%%%%%%%%%%

% Input quarter mesh coordiante
Node_coord.top = Node_coord_half;
N = length(Node_coord.top); % Number of nodes

switch option
    case 'bk08'

        % Input type 1 element connectivity, assumed to be bk08 elements
        bk08_conn.top = elm_conn_half;
        Nelm = length(bk08_conn.top);

    case 'wd06'
        % Input type 1 element connectivity, assumed to be wd06 elements
        wd06_conn.top = elm_conn_half;
        Nelm = length(wd06_conn.top);

end

%%
%%%%%%%%%%%%%%%%%%%%%%%% Full Mesh Generation %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Generate new nodal coordinates

% For bottom part, making y-coordiante negative
Node_coord.bottom = Node_coord.top;
Node_coord.bottom(:,3) = Node_coord.bottom(:,3) * -1;

% Combine all points and reordering, removing redundant part
Node_coord.all = [Node_coord.top;Node_coord.bottom];
Node_coord.fin = Node_coord.all;

% Remove redundant points on x-axis, i.e. y = 0
index.y = find(abs(Node_coord.all(:,3)) == 0); % Find all points with y = 0
index.yred = index.y(length(index.y)/2+1:end); % Index of redundant points
Node_coord.fin(index.yred,:) = [];


Node_coord.fin(:,1) = 1:length(Node_coord.fin(:,1));
Node_coord_fin = Node_coord.fin;

% Calculate number of reduction points for each part
nred.bottom = length(index.yred);

%% Generate element connectivity
% Construct Node list for element connectivity

% Find where y = 0
index2.y = find(abs(Node_coord.top(:,3)) == 0);

% Construct Node coordinate used for element connectivity
% Bottom part.
Node_elm.all = Node_coord.all;
index2.Nex = ismember(1:length(Node_elm.all(:,1)),index.yred)';
Node_elm.all(~index2.Nex,:) = Node_coord.fin;


% bottom part
% Change numbering at corresponding location
Node_elm.all(index.yred,1) = Node_elm.all(index2.y,1);

% Type 1 Element - bk08 elements
% Assign different parts of the element and interchange corresponding rows
% and columns

% For bottom part, change top and bottom surface
switch option
    case 'bk08'
        bk08_conn.bottom = bk08_conn.top+ones(Nelm,9)*N;
        bk08_conn.bottom(:,2:9) = [bk08_conn.bottom(:,6:9) bk08_conn.bottom(:,2:5)];

        % Assemble all parts.
        bk08_conn.all = [bk08_conn.top;bk08_conn.bottom];
        bk08_conn.all(:,1) = 1:length(bk08_conn.all(:,1));

        % Mapping index to the actual node numbering
        for i = Nelm+1:2*Nelm
            for j = 1:8
                bk08_conn.all(i,j+1) = Node_elm.all(bk08_conn.all(i,j+1),1);
            end
        end
        elm_conn_fin= bk08_conn.all;

    case 'wd06'

        % Type 2 Element - wd06 elements
        % For bottom part, change top and bottom surface

        wd06_conn.bottom = wd06_conn.top+ones(Nelm,7)*N;
        wd06_conn.bottom(:,2:7) = [wd06_conn.bottom(:,5:7) wd06_conn.bottom(:,2:4)];

        % Assemble all parts.
        wd06_conn.all = [wd06_conn.top;wd06_conn.bottom];
        wd06_conn.all(:,1) = (1:length(wd06_conn.all(:,1)))'; %+ ones(Nelm2*4,1) * Nelm1*2;

        % Mapping index to the actual node numbering
        for i = Nelm+1:2*Nelm
            for j = 1:6
                wd06_conn.all(i,j+1) = Node_elm.all(wd06_conn.all(i,j+1),1);
            end
        end
        elm_conn_fin= wd06_conn.all;
end

%% Processing partition information
N_part = PARTITION.General.N;
for i = 1:N_part
    PARTITION.(['Part' num2str(i+N_part)]).elm = PARTITION.(['Part' num2str(i)]).elm + Nelm;
    index3 = PARTITION.(['Part' num2str(i)]).nodID + N;
    PARTITION.(['Part' num2str(i+N_part)]).nodID = Node_elm.all(index3);
end

PARTITION.General.N = PARTITION.General.N*2;
end
% %%
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Output %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% writematrix(Node_coord.fin,'Full_mesh.txt','Delimiter','tab');
% if Nelm1 > 0
% writematrix(bk08_conn.all,'Full_mesh.txt','Delimiter','tab','WriteMode','append');
% end
% if Nelm2>0 
%     writematrix(wd06_conn.all,'Full_mesh.txt','Delimiter','tab','WriteMode','append');
% end