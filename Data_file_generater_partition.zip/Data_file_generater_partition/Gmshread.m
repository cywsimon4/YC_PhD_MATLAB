function PARTITION = Gmshread(file_name,node_coord,elm_conn)

%%  %%%%%%%%%%%%%%%%%%%%%%%%% Introduction %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% This subroutine split nodal coordinate, element connectivity, partition information
% from data file output by Gmsh

%%  %%%%%%%%%%%%%%%%%%%%%%%%% Reading stage %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This part reads all required information from target
% data file

% Open the file for reading
fid = fopen(file_name, 'r');
if fid == -1
    error('Cannot open the file');
end
rdlflag_part = 0;           % Flag indicating reading partition information
N_part = 1;                 % Index of partition
PARTITION.Part1.elm = [];

% Loop through each line of file to find the nodal coordiante and element
% connectivity

while ~feof(fid)
    line = fgetl(fid);

    if rdlflag_part == 1
        cellArr = strsplit(line);
        cellArr = str2double(cellArr); % Convert cell array to matrix
        cellArr(isnan(cellArr)) = [];
        NumElmline = length(cellArr);
        PARTITION.(['Part' num2str(N_part)]).elm(end+1:end+NumElmline) = cellArr';
    end
   
    % Read partition information
    pattern = 'Element sets';
    matches = regexp(line, pattern);
    if ~isempty(matches) && rdlflag_part == 0
        rdlflag_part = 1;
    elseif isempty(line) && rdlflag_part == 1
        rdlflag_part = 0;
        N_part = N_part+1;
        PARTITION.(['Part' num2str(N_part)]).elm=[];
    end
end


% re-numbering element connectivity
% elm_conn = sortrows(elm_conn(2:end,:));
elm1_index = min(elm_conn(:,1))-1; % Calculate start indexing of element defined in Gmsh
%elm_conn(:,1) = elm_conn(:,1) - elm1_index;  % to make element numbering start from 1;

% Store partition information
PARTITION.General.N = N_part;      % Number of partition

%%  %%%%%%%%%%%%%%%%%%%%%%%% Processing stage %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Find nodes belonging to each partition and also their index in element
% connectivity
% If only one partition then no need for extracting information
if N_part==1
    return
end

% Assume in elm_conn, the elements are ordered in those specified by
% partition information.
for i = 1:N_part
    PARTITION.(['Part' num2str(i)]).nodID = [];
    PARTITION.(['Part' num2str(i)]).elm = PARTITION.(['Part' num2str(i)]).elm - elm1_index;
    N_elm_part =  length(PARTITION.(['Part' num2str(i)]).elm);
    
    for j = 1:N_elm_part
        nodID1 = elm_conn(PARTITION.(['Part' num2str(i)]).elm(j),2:7);   % wd06 wedge element
        nodID_red = nodID1(~ismember(nodID1,PARTITION.(['Part' num2str(i)]).nodID));
        N_nod_red = length(nodID_red);
        PARTITION.(['Part' num2str(i)]).nodID(end+1:end+N_nod_red) = nodID_red;
    end
    PARTITION.(['Part' num2str(i)]).nodID = sort(PARTITION.(['Part' num2str(i)]).nodID);
end


end

