function PARTITION_H = Hierachical_FormRL(PARTITION,PARTITION_H,HIERACHICAL,level)
%%  %%%%%%%%%%%%%%%%%%%%%%%%% Introduction %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% This subroutine automatically form restraints and loading groups for
% parent elements at different levels

%%  %%%%%%%%%%%%%%%%%%%%%%%%% Assemble stage %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if level < HIERACHICAL.level
    for i = 1:HIERACHICAL.(['lv' num2str(level+1)]).N
        PARTITION_H.(['Part' num2str(i)]) =  Hierachical_FormRL(PARTITION,PARTITION_H.(['Part' num2str(i)]),HIERACHICAL,level+1);
    end

    PARTITION_H = FormResLoad(PARTITION,PARTITION_H,level);

elseif level == HIERACHICAL.level

   PARTITION_H = FormResLoad(PARTITION,PARTITION_H,level);

end


% =========================================================================

    function PARTITION_H = FormResLoad(PARTITION,PARTITION_H,level)

        % Create group and aditional nodes for coupling

        if PARTITION.Parent.node.adflag == 1
            % Find the index of group in PARTITION.Parent that corresponds
            % to coupling element
            for j = 1:PARTITION.Parent.grp.N
                if strcmp(PARTITION.Parent.grp.(['Grp' num2str(j)]).type,'cpl2')
                   Grp = PARTITION.Parent.grp.(['Grp' num2str(j)]);
                   break
                end
            end

            index_res = find(PARTITION_H.Parent.node.Coord(:,3) == -0.5);
            index_res = PARTITION_H.Parent.node.Coord(index_res,1);
            if level ~= 0
                index_res=setdiff(index_res,PARTITION_H.nodID_boundary);
            end

            if ~isempty(index_res)
                PARTITION_H.Parent.grp.N = PARTITION_H.Parent.grp.N+1;
                x = PARTITION_H.Parent.grp.N;
                PARTITION_H.Parent.grp.(['Grp' num2str(x)]) = Grp;

                % If there are nodes in the partition belong to the desired
                % boundary, then create additonal slave node for coupling
                PARTITION_H.Parent.node.Coord_ad = [30000 0 -0.5 0];

                % Create group 3 coupling element
                PARTITION_H.Parent.element.(['Grp' num2str(x)]).Nelm = length(index_res);
                PARTITION_H.Parent.element.(['Grp' num2str(x)]).Conn = zeros(length(index_res),3);
                PARTITION_H.Parent.element.(['Grp' num2str(x)]).Conn = [(20001:20000+length(index_res))' index_res ones(length(index_res),1)*30000];
                PARTITION_H.Parent.element.(['Grp' num2str(x)]).grp = 'gc1';

                % Restraint on additional node has to be defined explcitly
                PARTITION_H.Parent.node.adflag = 1;
                PARTITION_H.Parent.res.N = 1;
                PARTITION_H.Parent.res.(['Grp' num2str(1)]) = PARTITION.Parent.res.(['Grp' num2str(1)]);
            else
                PARTITION_H.Parent.node.adflag = 0;
                PARTITION_H.Parent.res.N = 0;
            end
        end
        % Form restraint group

        for j = 1:PARTITION.Parent.res.N

            % Eliminate nodes on the boundary
            index_res = intersect(PARTITION_H.Parent.node.Coord(:,1),PARTITION.Parent.res.(['Grp' num2str(j)]).node);

            % For parent element at branch nodes, need to eliminate nodes
            % from boundary

            if level ~= 0
              index_res=setdiff(index_res,PARTITION_H.nodID_boundary);
            end

            if ~isempty(index_res)
                PARTITION_H.Parent.res.N = PARTITION_H.Parent.res.N+1;
                PARTITION_H.Parent.res.(['Grp' num2str(PARTITION_H.Parent.res.N)]) = PARTITION.Parent.res.(['Grp' num2str(j)]);
                PARTITION_H.Parent.res.(['Grp' num2str(PARTITION_H.Parent.res.N)]).node = index_res;
                PARTITION_H.Parent.res.(['Grp' num2str(PARTITION_H.Parent.res.N)]).spec_method = 1;
            end

        end

        % Form loading group
        % Loop over all the loading group
        for j = 1:PARTITION.Parent.load.N

            % Eliminate nodes on the boundary
            index_load = intersect(PARTITION_H.Parent.node.Coord(:,1),PARTITION.Parent.load.(['Grp' num2str(j)]).node);

            % For parent element at branch nodes, need to eliminate nodes
            % from boundary

            if level ~= 0
              index_load=setdiff(index_load,PARTITION_H.nodID_boundary);
            end

            if ~isempty(index_load)
                PARTITION_H.Parent.load.N = PARTITION_H.Parent.load.N+1;
                PARTITION_H.Parent.load.(['Grp' num2str(PARTITION_H.Parent.load.N)]) = PARTITION.Parent.load.(['Grp' num2str(j)]);
                PARTITION_H.Parent.load.(['Grp' num2str(PARTITION_H.Parent.load.N)]).node = index_load;

                % Create curve information
                PARTITION_H.Parent.curve = PARTITION.Parent.curve;

            else
                PARTITION_H.Parent.curve.flag = 0;
            end

        end

        % Create group and aditional nodes for lumped mass(Based on existing
        % knowledge of specific form of loading in SNEP problem)
        if PARTITION_H.Parent.load.N~=0
            PARTITION_H.Parent.grp.N = PARTITION_H.Parent.grp.N+1;
            x = PARTITION_H.Parent.grp.N;
            y = PARTITION.Parent.grp.N;
            PARTITION_H.Parent.grp.(['Grp' num2str(x)]) = PARTITION.Parent.grp.(['Grp' num2str(y)]);

            % Create group lumped mass element

            PARTITION_H.Parent.element.(['Grp' num2str(x)]).Nelm = size(PARTITION_H.Parent.load.(['Grp' num2str(1)]).node,1);
            mass_index = [30001:30000+PARTITION_H.Parent.element.(['Grp' num2str(x)]).Nelm]';
            PARTITION_H.Parent.element.(['Grp' num2str(x)]).Conn = [mass_index  PARTITION_H.Parent.load.(['Grp' num2str(1)]).node];

            PARTITION_H.Parent.element.(['Grp' num2str(x)]).grp = 'm1';

        end

    end

end

