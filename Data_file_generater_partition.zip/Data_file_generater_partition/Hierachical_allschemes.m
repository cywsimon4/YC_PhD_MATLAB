% This m file records the hierachical scheme investigated

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Hierachical partition scheme 1
% 32 child partitions in total, 4 level 1 parent partitions

% % Level 0 partitioning
% HIERACHICAL.lv0.N = 1;   % Number of current level partitions
% HIERACHICAL.lv0.PartID = cell(HIERACHICAL.lv0.N,1);  % Records how individual partitions are grouped as a sub-parent partition by defining a cell
% HIERACHICAL.lv0.PartID{1,1} = [1 2 3 4];
% 
% % Level 1 partitioning
% HIERACHICAL.lv1.N = 4;   % Parent partition number for level 1
% HIERACHICAL.lv1.PartID = cell(HIERACHICAL.lv1.N,1);  % Records how individual partitions are grouped as a sub-parent partition by defining a cell
% HIERACHICAL.lv1.PartID{1,1} = [1:4 17:20];
% HIERACHICAL.lv1.PartID{2,1} = [5 6 8 15 21 22 24 31];
% HIERACHICAL.lv1.PartID{3,1} = [7 12 13 14 23 28 29 30];
% HIERACHICAL.lv1.PartID{4,1} = [9 10 11 16 25 26 27 32];

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Hierachical partition scheme 2
% 32 child partitions in total, 8 level 1 parent partitions

% % Level 0 partitioning
% HIERACHICAL.lv0.N = 1;   % Number of current level partitions
% HIERACHICAL.lv0.PartID = cell(HIERACHICAL.lv0.N,1);  % Records how individual partitions are grouped as a sub-parent partition by defining a cell
% HIERACHICAL.lv0.PartID{1,1} = 1:8;
% 
% % Level 1 partitioning
% HIERACHICAL.lv1.N = 8;   % Parent partition number for level 1
% HIERACHICAL.lv1.PartID = cell(HIERACHICAL.lv1.N,1);  % Records how individual partitions are grouped as a sub-parent partition by defining a cell
% HIERACHICAL.lv1.PartID{1,1} = [1:4];
% HIERACHICAL.lv1.PartID{2,1} = [5 6 8 15];
% HIERACHICAL.lv1.PartID{3,1} = [7 12 13 14];
% HIERACHICAL.lv1.PartID{4,1} = [9 10 11 16];
% HIERACHICAL.lv1.PartID{5,1} = [17:20];
% HIERACHICAL.lv1.PartID{6,1} = [21 22 24 31];
% HIERACHICAL.lv1.PartID{7,1} = [23 28 29 30];
% HIERACHICAL.lv1.PartID{8,1} = [25 26 27 32];

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Hierachical partition scheme 3
% 16 child partitions in total, 4 level 1 parent partitions

% % Level 0 partitioning
% HIERACHICAL.lv0.N = 1;   % Number of current level partitions
% HIERACHICAL.lv0.PartID = cell(HIERACHICAL.lv0.N,1);  % Records how individual partitions are grouped as a sub-parent partition by defining a cell
% HIERACHICAL.lv0.PartID{1,1} = 1:4;
% 
% % Level 1 partitioning
% HIERACHICAL.lv1.N = 4;   % Parent partition number for level 1
% HIERACHICAL.lv1.PartID = cell(HIERACHICAL.lv1.N,1);  % Records how individual partitions are grouped as a sub-parent partition by defining a cell
% HIERACHICAL.lv1.PartID{1,1} = [1,5,9,13];
% HIERACHICAL.lv1.PartID{2,1} = [2,6,10,14];
% HIERACHICAL.lv1.PartID{3,1} = [4,7,12,15];
% HIERACHICAL.lv1.PartID{4,1} = [3,8,11,16];


%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Hierachical partition scheme 4
% 8 child partitions in total, 4 level 1 parent partitions

% % Level 0 partitioning
% HIERACHICAL.lv0.N = 1;   % Number of current level partitions
% HIERACHICAL.lv0.PartID = cell(HIERACHICAL.lv0.N,1);  % Records how individual partitions are grouped as a sub-parent partition by defining a cell
% HIERACHICAL.lv0.PartID{1,1} = 1:4;
% 
% % Level 1 partitioning
% HIERACHICAL.lv1.N = 4;   % Parent partition number for level 1
% HIERACHICAL.lv1.PartID = cell(HIERACHICAL.lv1.N,1);  % Records how individual partitions are grouped as a sub-parent partition by defining a cell
% HIERACHICAL.lv1.PartID{1,1} = [1,2];
% HIERACHICAL.lv1.PartID{2,1} = [3,4];
% HIERACHICAL.lv1.PartID{3,1} = [5,6];
% HIERACHICAL.lv1.PartID{4,1} = [7,8];

