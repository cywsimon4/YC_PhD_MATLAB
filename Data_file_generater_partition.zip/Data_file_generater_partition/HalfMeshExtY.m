function [Node_coord_fin,elm_conn_fin,PARTITION] = HalfMeshExtY(Node_coord_half,elm_conn_half,option,PARTITION)
% Yiwei Chen
% Last updated: 06/03/2022
% Update: 

%%%%%%%%%%%%%%%%%%%%%%%%%%% Introduction %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This is the MATLAB file for generating the full size mesh from any
% arbitrary half mesh model symmetric about y axis (x=0)

%%%%%%%%%%%%%%%%%%%%%% Initialisation and input %%%%%%%%%%%%%%%%%%%%%%%%%%%

% Input quarter mesh coordiante
Node_coord.left = Node_coord_half;
N = length(Node_coord.left); % Number of nodes

switch option
    case 'bk08'

        % Input type 1 element connectivity, assumed to be bk08 elements
        bk08_conn.left = elm_conn_half;
        Nelm = length(bk08_conn.left);

    case 'wd06'
        % Input type 1 element connectivity, assumed to be wd06 elements
        wd06_conn.left = elm_conn_half;
        Nelm = length(wd06_conn.left);

end

%%
%%%%%%%%%%%%%%%%%%%%%%%% Full Mesh Generation %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Generate new nodal coordinates

% For right part, making x-coordiante negative
Node_coord.right = Node_coord.left;
Node_coord.right(:,2) = Node_coord.right(:,2) * -1;

% Combine all points and reordering, removing redundant part
Node_coord.all = [Node_coord.left;Node_coord.right];
Node_coord.fin = Node_coord.all;

% Remove redundant points on y-axis, i.e. x = 0
index.x = find(abs(Node_coord.all(:,2)) == 0); % Find all points with y = 0
index.xred = index.x(length(index.x)/2+1:end); % Index of redundant points
Node_coord.fin(index.xred,:) = [];


Node_coord.fin(:,1) = 1:length(Node_coord.fin(:,1));
Node_coord_fin = Node_coord.fin;

% Calculate number of reduction points for each part
nred.right = length(index.xred);

%% Generate element connectivity
% Construct Node list for element connectivity

% Find where x = 0
index2.x = find(abs(Node_coord.left(:,2)) == 0);

% Construct Node coordinate used for element connectivity
% Bottom part.
Node_elm.all = Node_coord.all;
index2.Nex = ismember(1:length(Node_elm.all(:,1)),index.xred)';
Node_elm.all(~index2.Nex,:) = Node_coord.fin;


% right part
% Change numbering at corresponding location
Node_elm.all(index.xred,1) = Node_elm.all(index2.x,1);

% Type 1 Element - bk08 elements
% Assign different parts of the element and interchange corresponding rows
% and columns

% For right part, change left and right surface
switch option
    case 'bk08'
        bk08_conn.right = bk08_conn.left+ones(Nelm,9)*N;
        bk08_conn.right(:,2:5) = [bk08_conn.right(:,3) bk08_conn.right(:,2) bk08_conn.right(:,5) bk08_conn.right(:,4)];
        bk08_conn.right(:,6:9) = [bk08_conn.right(:,7) bk08_conn.right(:,6) bk08_conn.right(:,9) bk08_conn.right(:,8)];

        % Assemble all parts.
        bk08_conn.all = [bk08_conn.left;bk08_conn.right];
        bk08_conn.all(:,1) = 1:length(bk08_conn.all(:,1));

        % Mapping index to the actual node numbering
        for i = Nelm+1:2*Nelm
            for j = 1:8
                bk08_conn.all(i,j+1) = Node_elm.all(bk08_conn.all(i,j+1),1);
            end
        end
        elm_conn_fin= bk08_conn.all;
    case 'wd06'

        % Type 2 Element - wd06 elements
        % For right part, change top and bottom surface

        wd06_conn.right = wd06_conn.left+ones(Nelm,7)*N;
        wd06_conn.right(:,2:3) = [wd06_conn.right(:,3) wd06_conn.right(:,2)];
        wd06_conn.right(:,5:6) = [wd06_conn.right(:,6) wd06_conn.right(:,5)];

        % Assemble all parts.
        wd06_conn.all = [wd06_conn.left;wd06_conn.right];
        wd06_conn.all(:,1) = 1:length(wd06_conn.all(:,1));

        % Mapping index to the actual node numbering
        for i = Nelm+1:2*Nelm
            for j = 1:6
                wd06_conn.all(i,j+1) = Node_elm.all(wd06_conn.all(i,j+1),1);
            end
        end
        elm_conn_fin= wd06_conn.all;

end
