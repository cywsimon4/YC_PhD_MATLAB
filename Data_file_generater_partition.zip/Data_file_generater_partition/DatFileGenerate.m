clc;
clear;
close all;

%%  %%%%%%%%%%%%%%%%%%%%%%%%%% Introduction %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% This file generates single data file for ADAPTIC

%%  %%%%%%%%%%%%%%%%%%%%%%%% Define file name %%%%%%%%%%%%%%%%%%%%%%%%%%%%%

file_name = 'Example.dat';

%%  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Input %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%==========================================================================

% Input description of the data file
DESCRIPTION.Aim='Example data file used to validate this code';
DESCRIPTION.Prob = 'Fill in problem description';
DESCRIPTION.Mesh = 'Fill in element types, sizes and characteristics';
DESCRIPTION.Mat = 'Fill in type of material model';
DESCRIPTION.Trace = 'Fill in tracing strategy, static/dynamic?';
dt = datetime('today');
DESCRIPTION.FileModDate = datestr(dt,'dd/mm/yyyy');

%========================================================================

% Input type of analysis
Type_ana_text = '3d.continuum dynamics';

%========================================================================
% Input material properties
MAT.N = 1;   % Number of materials used in analysis

% Material 1
MAT.Mat1.name = 'mat1';
MAT.Mat1.model = 'beth';
MAT.Mat1.properties = '1e3 0.3 0';

%========================================================================
% Input group properties
GRP.N = 1;  % Number of groups in total

% Group 1
GRP.Grp1.type = 'wd06';
GRP.Grp1.name = 'gp1';
GRP.Grp1.mat = 'mat1';
GRP.Grp1.prop_name = 'mat.name    gauss.points    density';
GRP.Grp1.prop_val = 'mat1    6    8e-9 ';
GRP.Grp1.nod_num = 6;    % Required node number

%========================================================================
% Input nodal coordinates and element connectivity (either by manual input 
% or from external sources such as Gmsh or Abaqus, the nodal coordinates 
% should be input in form of 2D array with four columns)

% For nodal coordinates: following fields must be provided
% Coord: 4 columns with id, x,y,z coordinates
% Coord_ad: Any other additional nodes

% For element connectivity: following fields must be provided for each
% group
% grp: corresponding group name
% Nelm: number of element
% Conn: element ID, Node ID being connected


% Group 1

% Input option 1: from predefined text file (e.g. from ABAQUS)
% Nodal coordinate
NODE.Coord = load('nodal coordinate.txt'); 

% Any additional nodes
NODE.Coord_ad = [30000, 0, -0.5, 0];
NODE.adflag = 0;        % 0: no additional nodes; 1: additional node required

 % Element connectivity
ELEMENT.Grp1.Conn = load('element conn.txt');    
ELEMENT.Grp1.Nelm = length(ELEMENT.Grp1.Conn);
ELEMENT.Grp1.grp = GRP.Grp1.name;
PARTITION.General.N = 1;

% Any post-processing of node data
% [NODE.Coord,ELEMENT.Grp1.Conn,PARTITION] = HalfMeshExtX(NODE.Coord_half,ELEMENT.Grp1.Conn_half,'wd06',PARTITION);

% Input option 2: Manual input with intrinsic incrementation syntax in
% ADAPTIC, in this case the element and node struct are named as 'NODE_INC'
% and 'ELEMENT_INC', same applied to all other quantities.

%========================================================================

% Input restraint group properties
RES.N = 2;  % Number of groups in total

% Group 1

% Example: restrain y-displacement at nodes along line y=-50
RES.Grp1.dir = 'y';
index_res = find(NODE.Coord(:,3) == -50);
RES.Grp1.node = NODE.Coord(index_res,1);
RES.Grp1.spec_method = 1;   % 1: node list, 2: incrementation, 3:mixed

% Group 2

% Example: restrain z-displacement at all nodes (automatic incrementation from 1 to the end of node index) 
RES.Grp2.dir= 'z';
RES.Grp2.num_inc = 1;
RES.Grp2.node_inc1= [1 0;1 length(NODE.Coord)-1];

%             Array             ADAPTIC notation
% ----------------------------------------------------
% node_inc1: [a    0        |     f    a
%             b    c]       |     r    b    c

RES.Grp2.spec_method = 2;   % 1: node list, 2: incrementation, 3:mixed


%========================================================================

% Input integration scheme parameter
INTSCHEME.scheme = 'hilber';
INTSCHEME.para_N = 1;  % Number of parameter
INTSCHEME.para_name = strings(1);
INTSCHEME.para_name(1) = 'alpha';
INTSCHEME.para_val = -0.333;


% Semi-explicit scheme
% INTSCHEME.scheme = 'newmark';
% INTSCHEME.para_N = 2;  % Number of parameter
% INTSCHEME.para_name = strings(2);
% INTSCHEME.para_name(1) = 'beta';
% INTSCHEME.para_name(2) = 'gamma';
% INTSCHEME.para_val = [0.25 0.5];

%========================================================================

% Input loading curve (Assume only one curve, more curves can be added by
% adding more groups)
CURVE.flag = 1;    % 1: curve is required; 0: curve is not required
CURVE.start_time = '0';
CURVE.name = 'c1';
CURVE.xypoints = [200 1];   % Points in time-load factor space to define the curve

%========================================================================

% Input loading group 

LOAD.N = 2;

% Group1
LOAD.Grp1.name = 'initial.loads';
LOAD.Grp1.dir = 'x';
LOAD.Grp1.type = 'v';
LOAD.Grp1.value = '100';
index_res = find(NODE.Coord(:,2) == -50 & NODE.Coord(:,3) < -25);
LOAD.Grp1.node = NODE.Coord(index_res,1);
LOAD.Grp1.spec_method = 1;   % 1: node list, 2: incrementation, 3:mixed

% Group2
LOAD.Grp2 = LOAD.Grp1;
LOAD.Grp2.name = 'dynamic.loads';
LOAD.Grp2.type = 'a';
LOAD.Grp2.value = '0';
LOAD.Grp2.crv = 'c1';

%========================================================================

% Input equilibrium stage
EQUI.xypoints = [100  100];

%========================================================================

% Input solution of equations
SOLVER.type = 'mumps';

%========================================================================

% Input iterative strategy
ITERSTRAT.number = '10';    % Number of maximum iteration allowed
ITERSTRAT.reform = '10';    % Number of iterations allowed to recalculate tangent stiffness
ITERSTRAT.reduction = '10';    % Number of substeps created when convergence issue
ITERSTRAT.div = '10';    % Number of iterations to check divergence
ITERSTRAT.maxconv = '1e7';    % tolerance to be classified as divergence

%========================================================================

% Input convergence criteria
CONV.tol = '1e-4';    % tolerance
CONV.ref_type = 'w';    % 'w': work reference; 'fm' force & moment refernce
CONV.ref1 = '1e5';    % Number of iterations allowed to recalculate tangent stiffness
CONV.ref2 = '1e5';    % Number of iterations allowed to recalculate tangent stiffness

%========================================================================

% Input output frequency
OUTPUT.freq = '5 stress';

%========================================================================
% End of input stage

%%  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Writing %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%#
% Open a file for writing

fileID = fopen(file_name, 'w');

%========================================================================

% Write description of the data file
fprintf(fileID, '#====================== Description =========================\n');
fprintf(fileID, '#-Aim: %s;\n',DESCRIPTION.Aim);
fprintf(fileID, '#-Problem description: %s;\n',DESCRIPTION.Prob);
fprintf(fileID, '#-Mesh description: %s;\n',DESCRIPTION.Mesh);
fprintf(fileID, '#-Material description: %s;\n',DESCRIPTION.Mat);
fprintf(fileID, '#-Tracing tech. description: %s;\n',DESCRIPTION.Trace);
fprintf(fileID, '#  \n');
fprintf(fileID, '#-Created on: %s\n',DESCRIPTION.FileModDate);
fprintf(fileID, '#-Last modified on: \n');
fprintf(fileID, '#============================================================\n');
fprintf(fileID, '#  \n');

%========================================================================

% Write type of the data file
fprintf(fileID, 'analysis %s\n',Type_ana_text);
fprintf(fileID, '#  \n');

%========================================================================

% Write material properties
fprintf(fileID, 'materials\n');
fprintf(fileID, '  mat.name     model     properties\n');
for i = 1:MAT.N
    fprintf(fileID, '  %s    %s     %s\n',MAT.(['Mat' num2str(i)]).name,MAT.(['Mat' num2str(i)]).model,MAT.(['Mat' num2str(i)]).properties);
end
fprintf(fileID, '#  \n');

%========================================================================

% Write group properties
fprintf(fileID, 'groups\n');
for i = 1:GRP.N
    fprintf(fileID, 'type = %s\n',GRP.(['Grp' num2str(i)]).type);
    fprintf(fileID, '  grp.name    %s\n',GRP.(['Grp' num2str(i)]).prop_name);
    fprintf(fileID, '  %s    %s\n',GRP.(['Grp' num2str(i)]).name,GRP.(['Grp' num2str(i)]).prop_val);
    fprintf(fileID, '#  \n');
end

%========================================================================

% Write nodal coordinate information
fprintf(fileID, 'structural.nodal\n');
fprintf(fileID, '  nod.name     x   y   z\n');
for i = 1:length(NODE.Coord)
    fprintf(fileID,'  %s     %s   %s   %s\n',num2str(NODE.Coord(i,1)), num2str(NODE.Coord(i,2)),num2str(NODE.Coord(i,3)),num2str(NODE.Coord(i,4)));
end
% Any additional nodes
if NODE.adflag
    for i = 1:length(NODE.Coord_ad)
        fprintf(fileID,'  %s     %s   %s   %s\n',num2str(NODE.Coord_ad(i,1)), num2str(NODE.Coord_ad(i,2)),num2str(NODE.Coord_ad(i,3)),num2str(NODE.Coord_ad(i,4)));
    end
end
fprintf(fileID, '#  \n');

%========================================================================

% Write element connectivity information
fprintf(fileID, 'element.connectivity\n');
for i =1:GRP.N
    fprintf(fileID, '  grp.name = %s\n', ELEMENT.(['Grp' num2str(i)]).grp);
    fprintf(fileID, '  elm.name       nod.name\n');
    for j = 1:ELEMENT.(['Grp' num2str(i)]).Nelm
        for k = 1:size(ELEMENT.(['Grp' num2str(i)]).Conn,2)
           fprintf(fileID,'  %s',num2str(ELEMENT.(['Grp' num2str(i)]).Conn(j,k)));
           if k == 1
               fprintf(fileID,'      ');
           end
        end
        fprintf(fileID,'\n');
    end

    fprintf(fileID, '#  \n');
end

%========================================================================

% Write restraint information
fprintf(fileID, 'restraints\n');
for i = 1:RES.N
    fprintf(fileID, ' direction = %s\n',RES.(['Grp' num2str(i)]).dir);
    fprintf(fileID, '  nod.name\n');

    switch RES.(['Grp' num2str(i)]).spec_method
        case 1
            for j = 1:length(RES.(['Grp' num2str(i)]).node)
               fprintf(fileID, '  %s\n',num2str(RES.(['Grp' num2str(i)]).node(j)));
            end
        case 2
            for j = 1:RES.(['Grp' num2str(i)]).num_inc
                fprintf(fileID, 'f   %s\n',num2str(RES.(['Grp' num2str(i)]).(['node_inc' num2str(j)])(1,1)));  % First line
                for k = 2:size(RES.(['Grp' num2str(i)]).(['node_inc' num2str(j)]),1)
                   fprintf(fileID, 'r   %s   %s\n',num2str(RES.(['Grp' num2str(i)]).(['node_inc' num2str(j)])(k,1)),num2str(RES.(['Grp' num2str(i)]).(['node_inc' num2str(j)])(k,2)));
                end
            end
        case 3
            % Doing both
            for j = 1:RES.(['Grp' num2str(i)]).num_inc
                fprintf(fileID, 'f   %s\n',num2str(RES.(['Grp' num2str(i)]).(['node_inc' num2str(j)])(1,1)));  % First line
                for k = 2:size(RES.(['Grp' num2str(i)]).(['node_inc' num2str(j)]),1)
                    fprintf(fileID, 'r   %s   %s\n',num2str(RES.(['Grp' num2str(i)]).(['node_inc' num2str(j)])(k,1)),num2str(RES.(['Grp' num2str(i)]).(['node_inc' num2str(j)])(k,2)));
                end
            end
            for j = 1:length(RES.(['Grp' num2str(i)]).node)
                fprintf(fileID, '  %s\n',num2str(RES.(['Grp' num2str(i)]).node(j)));
            end
    end
    fprintf(fileID, '#  \n');
end

%========================================================================

% Write integration scheme information (only necessary in dynamic
% analysis)
if contains(Type_ana_text,'dynamic','IgnoreCase',true)
   fprintf(fileID, 'integration.scheme\n');
   fprintf(fileID, ' scheme = %s\n',INTSCHEME.scheme);
   for i = 1:INTSCHEME.para_N
       fprintf(fileID, ' %s = %s\n',INTSCHEME.para_name(i),num2str(INTSCHEME.para_val(i)));
   end
end
fprintf(fileID, '#  \n');

%========================================================================

% Write curve information (only necessary for time.history and dynamic
% loading)
if CURVE.flag == 1
   fprintf(fileID, 'linear.curve\n');
   fprintf(fileID, '  start.time = %s\n',CURVE.start_time);
   fprintf(fileID, '  crv.name = %s\n',CURVE.name);
   fprintf(fileID, '  time    load.factor\n');
   for i = 1:size(CURVE.xypoints,1)
       fprintf(fileID, ' %s     %s\n',num2str(CURVE.xypoints(i,1)),num2str(CURVE.xypoints(i,2)));
   end
end
fprintf(fileID, '#  \n');

%========================================================================

% Write loading information
fprintf(fileID, 'applied.loading\n');
for i = 1:LOAD.N
    fprintf(fileID, '  %s\n',LOAD.(['Grp' num2str(i)]).name);
    fprintf(fileID, '   direction = %s\n',LOAD.(['Grp' num2str(i)]).dir);
    fprintf(fileID, '   type = %s\n',LOAD.(['Grp' num2str(i)]).type);
    if contains(LOAD.(['Grp' num2str(i)]).name,'dynamic') || contains(LOAD.(['Grp' num2str(i)]).name,'time.history')
        fprintf(fileID, '   crv.name = %s\n',LOAD.(['Grp' num2str(i)]).crv);
    end
    fprintf(fileID, '   value = %s\n',LOAD.(['Grp' num2str(i)]).value); 
    fprintf(fileID, '   nod.name\n');

    switch LOAD.(['Grp' num2str(i)]).spec_method
        case 1
            for j = 1:length(LOAD.(['Grp' num2str(i)]).node)
               fprintf(fileID, '   %s\n',num2str(LOAD.(['Grp' num2str(i)]).node(j)));
            end
        case 2
            for j = 1:LOAD.(['Grp' num2str(i)]).num_inc
                fprintf(fileID, 'f    %s\n',num2str(LOAD.(['Grp' num2str(i)]).(['node_inc' num2str(j)])(1,1)));  % First line
                for k = 2:size(LOAD.(['Grp' num2str(i)]).(['node_inc' num2str(j)]),1)
                   fprintf(fileID, 'r    %s   %s\n',num2str(LOAD.(['Grp' num2str(i)]).(['node_inc' num2str(j)])(k,1)),num2str(LOAD.(['Grp' num2str(i)]).(['node_inc' num2str(j)])(k,2)));
                end
            end
        case 3
            % Doing both
            for j = 1:LOAD.(['Grp' num2str(i)]).num_inc
                fprintf(fileID, 'f    %s\n',num2str(LOAD.(['Grp' num2str(i)]).(['node_inc' num2str(j)])(1,1)));  % First line
                for k = 2:size(LOAD.(['Grp' num2str(i)]).(['node_inc' num2str(j)]),1)
                    fprintf(fileID, 'r    %s   %s\n',num2str(LOAD.(['Grp' num2str(i)]).(['node_inc' num2str(j)])(k,1)),num2str(LOAD.(['Grp' num2str(i)]).(['node_inc' num2str(j)])(k,2)));
                end
            end
            for j = 1:length(LOAD.(['Grp' num2str(i)]).node)
                fprintf(fileID, '   %s\n',num2str(LOAD.(['Grp' num2str(i)]).node(j)));
            end
    end
    fprintf(fileID, '#  \n');
end

%========================================================================

% Write equilibrium stage
fprintf(fileID, 'equilibrium.stages\n');
fprintf(fileID, '  end.of.stage   steps\n');
for i = 1:size(EQUI.xypoints,1)
    fprintf(fileID, '  %s      %s\n',num2str(EQUI.xypoints(i,1)),num2str(EQUI.xypoints(i,2)));
end
fprintf(fileID, '#  \n');

%========================================================================

% Write solver type
fprintf(fileID, 'solution.of.equations\n');
fprintf(fileID, '  solver = %s\n',SOLVER.type);
fprintf(fileID, '#  \n');

%========================================================================

% Write iterative strategy
fprintf(fileID, 'iterative.strategy\n');
fprintf(fileID, ' number = %s\n',ITERSTRAT.number);
fprintf(fileID, ' initial.reformation = %s\n',ITERSTRAT.reform);
fprintf(fileID, ' step.reduction = %s\n',ITERSTRAT.reduction);
fprintf(fileID, ' divergence.iteration = %s\n',ITERSTRAT.div);
fprintf(fileID, ' maximum.convergence = %s\n',ITERSTRAT.maxconv);
fprintf(fileID, '#  \n');

%========================================================================

% Write convergence criteria
fprintf(fileID, 'convergence.criteria\n');
fprintf(fileID, ' tolerance = %s\n',CONV.tol);
if strcmp('w',CONV.ref_type)
    fprintf(fileID, ' work.ref = %s\n',CONV.ref1);
elseif strcmp('fm',CONV.ref_type)
    fprintf(fileID, ' force.ref = %s\n',CONV.ref1);
    fprintf(fileID, ' moment.ref = %s\n',CONV.ref2);
else
    error('Input a valid refernce type')
end
fprintf(fileID, '#  \n');

%========================================================================

% Write output frequency (assume output stress by default)
fprintf(fileID, 'output\n');
fprintf(fileID, ' frequency %s \n',OUTPUT.freq);
fprintf(fileID, '#  \n');

%========================================================================

% end
fprintf(fileID, 'end');

%%  %%%%%%%%%%%%%%%%%%%%%%%%%%%% Close file %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Close the file
fclose(fileID);
