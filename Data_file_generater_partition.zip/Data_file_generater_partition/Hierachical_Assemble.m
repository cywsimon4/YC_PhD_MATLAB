function [PARTITION_H] = Hierachical_Assemble(PARTITION,PARTITION_H,HIERACHICAL,level,index)

%%  %%%%%%%%%%%%%%%%%%%%%%%%% Introduction %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% This subroutine automatically form a struct for hierachical partitioning
% by regrouping individual partitions

%%  %%%%%%%%%%%%%%%%%%%%%%%%% Assemble stage %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
if level <= HIERACHICAL.level
  total_supelm = size(HIERACHICAL.(['lv' num2str(level)]).PartID{index},2);
  PARTITION_H.N_subpart = total_supelm;
elseif level > HIERACHICAL.level
    error('Level exceeds maximum level allowed')
end

for i = 1:total_supelm
    ID = HIERACHICAL.(['lv' num2str(level)]).PartID{index}(i);
    if level == HIERACHICAL.level
        PARTITION_H.(['Part' num2str(i)]) = PARTITION.(['Part' num2str(ID)]);
        PARTITION_H.(['Part' num2str(i)]).level = level+1;
        PARTITION_H.(['Part' num2str(i)]).ID = ID;
    else
        PARTITION_H.(['Part' num2str(ID)]).level = level+1;
        PARTITION_H.(['Part' num2str(ID)]).General = PARTITION.General;
        PARTITION_H.(['Part' num2str(i)]).ID = ID;
        PARTITION_H.(['Part' num2str(ID)]) = Hierachical_Assemble(PARTITION,PARTITION_H.(['Part' num2str(ID)]),HIERACHICAL,level+1,ID);
    end
end

end

