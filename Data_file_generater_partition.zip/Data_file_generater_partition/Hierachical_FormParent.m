function [PARTITION_H] = Hierachical_FormParent(PARTITION,PARTITION_H,HIERACHICAL,level)

%%  %%%%%%%%%%%%%%%%%%%%%%%%% Introduction %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% This subroutine automatically form parent partitions at different
% levels and store it in a single struct PARTITION_H, assume only level 1
% partition modelling

%%  %%%%%%%%%%%%%%%%%%%%%%%%% Calling stage %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% The nested function FormParent forms parent element at current level. The
% following code automatically loops over all branches of hierachical
% partition structure and form parent at all necessary levels


if level < HIERACHICAL.level
  for i = 1:HIERACHICAL.(['lv' num2str(level+1)]).N
      PARTITION_H.(['Part' num2str(i)]) = Hierachical_FormParent(PARTITION,PARTITION_H.(['Part' num2str(i)]),HIERACHICAL,level+1);
  end
  [PARTITION_H] = FormParent(PARTITION,PARTITION_H,'branch');
elseif level == HIERACHICAL.level
  [PARTITION_H] = FormParent(PARTITION,PARTITION_H,'base');
end

if level == 0
    % Form equilibrium stages
    PARTITION_H.Parent.equi = PARTITION.Parent.equi;
end

% =========================================================================

    function [PARTITION_H] = FormParent(PARTITION,PARTITION_H,type)
        % This function automatically form parent element at current level
        
        switch type

            case 'branch'
                % =========================================================================
                % Branch node type

                % From all sub-parent elements, collects nodes on the
                % boundary
                % Firstly establish all nodes on the boundary at current level
                x = size(PARTITION.Parent.node.Coord,1);
                NodePartCounter = zeros(x,2); NodePartCounter(:,1) = PARTITION.Parent.node.Coord(:,1);
                for j = 1:PARTITION_H.N_subpart
                    [~,index] = ismember(PARTITION_H.(['Part' num2str(j)]).Parent.node.Coord(:,1),PARTITION.Parent.node.Coord(:,1));
                    index = nonzeros(index);
                    NodePartCounter(index,2) = NodePartCounter(index,2) + 1;
                end
                
                % Node information
                PARTITION_H.Parent.node.Coord = PARTITION.Parent.node.Coord(NodePartCounter(:,2)>1,:);

                % Once the nodes appearing twice or more, it means that the
                % nodes are at boundaries of two super elements

                NodePartCounter(NodePartCounter(:,2) <= 1,:) = [];

                % Loop over all parent partitions, find these nodes and the
                % corresponding additional dofs
                
                for j = 1:PARTITION_H.N_subpart
                    x = ismember(PARTITION_H.(['Part' num2str(j)]).Parent.node.Coord(:,1),NodePartCounter);
                    PARTITION_H.(['Part' num2str(j)]).nodID_boundary = PARTITION_H.(['Part' num2str(j)]).Parent.node.Coord(x,1);

                    % Additional dofs
                    % loop over all nodes on the boundary of current
                    % level;for each one locate the corresponding lower
                    % level of parent partition the node belongs to and
                    % find their index.
                    PARTITION_H.(['Part' num2str(j)]).dofAD_boundary= zeros(1,3);
                    for k = 1:length(PARTITION_H.(['Part' num2str(j)]).nodID_boundary)
                         for m = 1:PARTITION_H.(['Part' num2str(j)]).N_subpart
                                                          index = find(PARTITION_H.(['Part' num2str(j)]).(['Part' num2str(m)]).nodID_boundary == PARTITION_H.(['Part' num2str(j)]).nodID_boundary(k));
                             if ~isempty(index)

                                  PARTITION_H.(['Part' num2str(j)]).dofAD_boundary(end+1,:) = [PARTITION_H.(['Part' num2str(j)]).nodID_boundary(k) m index];
                                  break;
                             end
                         end
                    end
                    PARTITION_H.(['Part' num2str(j)]).dofAD_boundary = PARTITION_H.(['Part' num2str(j)]).dofAD_boundary(2:end,:);
                end

            case 'base'

                % =========================================================================
                % Base node type

                % Firstly establish all nodes on the boundary for current level
                x = size(PARTITION.Parent.node.Coord,1);
                NodePartCounter = zeros(x,2); NodePartCounter(:,1) = PARTITION.Parent.node.Coord(:,1);
                for j = 1:PARTITION_H.N_subpart
                    [~,index] = ismember(PARTITION_H.(['Part' num2str(j)]).nodID_boundary,PARTITION.Parent.node.Coord(:,1));
                    index = nonzeros(index);
                    NodePartCounter(index,2) = NodePartCounter(index,2) + 1;
                end

                % Node information
                PARTITION_H.Parent.node.Coord = PARTITION.Parent.node.Coord(NodePartCounter(:,2)~=0,:);

                NodePartCounter(NodePartCounter(:,2) == 0,:) = [];
        end

        % Group information
        % Create 1 super element group for each partition with differnt number of
        % boundary nodes
        PARTITION_H.Parent.grp.N = 0;
        PARTITION_H.General.Supelm.node_num = [];

        for j = 1:PARTITION_H.N_subpart

            if (~ismember(length(PARTITION_H.(['Part' num2str(j)]).nodID_boundary),PARTITION_H.General.Supelm.node_num))
                PARTITION_H.Parent.grp.N = PARTITION_H.Parent.grp.N+1;
                PARTITION_H.General.Supelm.node_num(end+1,:) = length(PARTITION_H.(['Part' num2str(j)]).nodID_boundary);
            end
        end

        for j = 1:PARTITION_H.Parent.grp.N
            PARTITION_H.Parent.grp.(['Grp' num2str(j)]).type = 'part';
            PARTITION_H.Parent.grp.(['Grp' num2str(j)]).name = ['gpp' num2str(j)];
            PARTITION_H.Parent.grp.(['Grp' num2str(j)]).prop_name = 'nodes      element.freedoms';
            PARTITION_H.Parent.grp.(['Grp' num2str(j)]).node = num2str(PARTITION_H.General.Supelm.node_num(j));
            PARTITION_H.Parent.grp.(['Grp' num2str(j)]).elmdof = num2str(PARTITION_H.General.Supelm.node_num(j));
            PARTITION_H.Parent.grp.(['Grp' num2str(j)]).node_num = PARTITION_H.General.Supelm.node_num(j);
            x = num2str(PARTITION_H.General.Supelm.node_num(j));
            PARTITION_H.Parent.grp.(['Grp' num2str(j)]).prop_val = [num2str(x) '         ' num2str(x)];

            % Element
            PARTITION_H.Parent.element.(['Grp' num2str(j)]).Conn = zeros(1,PARTITION_H.Parent.grp.(['Grp' num2str(j)]).node_num+1);
        end

        % Create element connectivity
        k = 0;
        for j = 1:PARTITION_H.N_subpart
            % Check current partition belong to which superelement
            x = find(PARTITION_H.General.Supelm.node_num == length(PARTITION_H.(['Part' num2str(j)]).nodID_boundary));
            k = k+1;
            PARTITION_H.Parent.element.(['Grp' num2str(x)]).Conn(end+1,:) = [k PARTITION_H.(['Part' num2str(j)]).nodID_boundary'];
        end

        for j = 1:PARTITION_H.Parent.grp.N
            PARTITION_H.Parent.element.(['Grp' num2str(j)]).Conn = PARTITION_H.Parent.element.(['Grp' num2str(j)]).Conn(2:end,:);
            PARTITION_H.Parent.element.(['Grp' num2str(j)]).Nelm = size(PARTITION_H.Parent.element.(['Grp' num2str(j)]).Conn,1);
        end

        % Additional freedom: need to determine which dofs are shared between which
        % two partitions and their locations as recorded in each child part
        % dofAD_boundary

        % for each node on the boundary, find which partition they belong to and
        % their index in the additional dof list defined in child partition
        % Create a mapping

        NodePartGroup = false(1,PARTITION_H.N_subpart);
        PARTITION_H.Parent.dofAD_couple = cell(1,2);
        PARTITION_H.Parent.dofAD_couple{1} = zeros(1,2);
        % First cell stores partition coupling information while second cell stores
        % dof coupling information


        % Populate the mapping
        for j = 1:size(NodePartCounter,1)
            for k = 1:PARTITION_H.N_subpart
                NodePartGroup(1, k) = ismember(NodePartCounter(j,1), PARTITION_H.(['Part' num2str(k)]).nodID_boundary);
            end

            % For all possible combination of partitions, coupling corresponding
            % dofs.
            % Find the first child partition containing the node/dof
            elm = find(NodePartGroup);
            elm1 = elm(1);
            for k = 1:sum(NodePartGroup)-1
                elm2 = elm(k+1);
                % If a node is connected to N partitions, then it always requires N-1 coupling,
                % Always coupling with first element to avoid confused coupling

                % Check if current partition combination has been established in
                % cell
                if ismember([elm1 elm2],PARTITION_H.Parent.dofAD_couple{1},'rows')
                    matchingRows = ismember(PARTITION_H.Parent.dofAD_couple{1}, [elm1 elm2], 'rows');
                    x = find(matchingRows)-1;
                    index1 = find(PARTITION_H.(['Part' num2str(elm1)]).nodID_boundary==NodePartCounter(j,1));
                    index2 = find(PARTITION_H.(['Part' num2str(elm2)]).nodID_boundary==NodePartCounter(j,1));
                    PARTITION_H.Parent.dofAD_couple{2}{x,1}(end+1) = index1;
                    PARTITION_H.Parent.dofAD_couple{2}{x,2}(end+1) = index2;

                else
                    PARTITION_H.Parent.dofAD_couple{1}(end+1,:) = [elm1 elm2];

                    % Find corresponding position of the node in corresponding
                    % partition
                    index1 = find(PARTITION_H.(['Part' num2str(elm1)]).nodID_boundary==NodePartCounter(j,1));
                    index2 = find(PARTITION_H.(['Part' num2str(elm2)]).nodID_boundary==NodePartCounter(j,1));
                    PARTITION_H.Parent.dofAD_couple{2}{end+1,1} = index1;
                    PARTITION_H.Parent.dofAD_couple{2}{end,2} = index2;
                end
            end

        end
        PARTITION_H.Parent.dofAD_couple{1} = PARTITION_H.Parent.dofAD_couple{1}(2:end,:);

        % Loading and restraint (Assume no loading implicitly
        % defined in any parent files, they need to defined outside current
        % function)
        PARTITION_H.Parent.load.N = 0;
        PARTITION_H.Parent.curve.flag = 0;
        PARTITION_H.Parent.node.adflag = 0;

        % Restraint
        PARTITION_H.Parent.res.N = 0;

        % Iterative strategy
        PARTITION_H.Parent.iterstrat = PARTITION.Parent.iterstrat;
    end

end