function [] = DatFileWrite_partition_H(PARTITION,part_type,file_name,part_index)
%%  %%%%%%%%%%%%%%%%%%%%%%%%% Introduction %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% This subroutine creates and writes data into corresponding .dat file
% according to information stored in partition

%%  %%%%%%%%%%%%%%%%%%%%%%%  Pre-processing %%%%%%%%%%%%%%%%%%%%%%%%%%%
% Open a file for writing
fileID = fopen(file_name, 'w');

if nargin < 4
   part_index = PARTITION.ID;
end

% Extracting information (General)
DESCRIPTION = PARTITION.General.description;
% Type of analysis
Type_ana_text = PARTITION.General.Type_ana_text;
% Integration scheme
INTSCHEME = PARTITION.General.intscheme ;
% Solver type
SOLVER = PARTITION.General.solver;
% Convergence criteria
CONV = PARTITION.General.conv ;

% Output
OUTPUT = PARTITION.General.output;

% Extracting information (Type-specific)
switch part_type
    case 'Parent'
        rank = PARTITION.rank;
        level = PARTITION.level;
        NODE = PARTITION.Parent.node;
        ELEMENT = PARTITION.Parent.element;
        GRP = PARTITION.Parent.grp;
        RES = PARTITION.Parent.res;
        LOAD = PARTITION.Parent.load;
        CURVE = PARTITION.Parent.curve;
        ITERSTRAT = PARTITION.Parent.iterstrat;
        DOFAD_COUPLE = PARTITION.Parent.dofAD_couple;
        if rank == 0
            EQUI = PARTITION.Parent.equi;
        else
            Parent_rank = PARTITION.Parent_rank;
            DOFAD_BOUNDARY = PARTITION.dofAD_boundary;
        end
        
    case 'Child'
        rank = PARTITION.(['Part' num2str(part_index)]).rank;
        level = PARTITION.(['Part' num2str(part_index)]).level;
        Parent_rank = PARTITION.(['Part' num2str(part_index)]).Parent_rank;

        NODE = PARTITION.(['Part' num2str(part_index)]).node;
        ELEMENT = PARTITION.(['Part' num2str(part_index)]).element;
        GRP = PARTITION.(['Part' num2str(part_index)]).grp;
        RES = PARTITION.(['Part' num2str(part_index)]).res;
        LOAD = PARTITION.(['Part' num2str(part_index)]).load;
        CURVE = PARTITION.(['Part' num2str(part_index)]).curve;
        MAT = PARTITION.(['Part' num2str(part_index)]).mat;
        DOFAD_BOUNDARY = PARTITION.(['Part' num2str(part_index)]).dofAD_boundary;

    otherwise
        error('Invalid partition type: Input either ''Parent'' or ''Child''');         
end

%========================================================================

% Write description of the data file
fprintf(fileID, '#====================== Description =========================\n');
fprintf(fileID, '#-Aim: %s;\n',DESCRIPTION.Aim);
fprintf(fileID, '#-Problem description: %s;\n',DESCRIPTION.Prob);
fprintf(fileID, '#-Mesh description: %s;\n',DESCRIPTION.Mesh);
fprintf(fileID, '#-Material description: %s;\n',DESCRIPTION.Mat);
fprintf(fileID, '#-Tracing tech. description: %s;\n',DESCRIPTION.Trace);

switch part_type
    case 'Parent'
        fprintf(fileID, '#-Rank: %s  \n',num2str(rank));
        fprintf(fileID, '#-Partition: Parent  \n');
        if rank~=0
            fprintf(fileID, '#-Level: %s  \n',num2str(level));
            fprintf(fileID, '#-ID: %s  \n',num2str(part_index));
        end

    case 'Child'
        fprintf(fileID, '#-Rank: %s  \n',num2str(rank));
        fprintf(fileID, '#-Level: %s  \n',num2str(level));
        fprintf(fileID, '#-Partition: Child #%s  \n',num2str(part_index));
   
end

fprintf(fileID, '#  \n');
fprintf(fileID, '#-Created on: %s\n',DESCRIPTION.FileModDate);
fprintf(fileID, '#-Last modified on: \n');
fprintf(fileID, '#============================================================\n');
fprintf(fileID, '#  \n');

%========================================================================

% Write type of the data file
fprintf(fileID, 'analysis %s\n',Type_ana_text);
fprintf(fileID, '#  \n');

%========================================================================

% Write material properties
if strcmp(part_type,'Child')
    fprintf(fileID, 'materials\n');
    fprintf(fileID, '  mat.name     model     properties\n');
    for i = 1:MAT.N
        fprintf(fileID, '  %s    %s     %s\n',MAT.(['Mat' num2str(i)]).name,MAT.(['Mat' num2str(i)]).model,MAT.(['Mat' num2str(i)]).properties);
    end
    fprintf(fileID, '#  \n');
end
%========================================================================

% Write group properties
fprintf(fileID, 'groups\n');
for i = 1:GRP.N
    fprintf(fileID, 'type = %s\n',GRP.(['Grp' num2str(i)]).type);
    fprintf(fileID, '  grp.name    %s\n',GRP.(['Grp' num2str(i)]).prop_name);
    fprintf(fileID, '  %s    %s\n',GRP.(['Grp' num2str(i)]).name,GRP.(['Grp' num2str(i)]).prop_val);
    fprintf(fileID, '#  \n');
end

%========================================================================

% Write nodal coordinate information
fprintf(fileID, 'structural.nodal\n');
fprintf(fileID, '  nod.name     x   y   z\n');
for i = 1:length(NODE.Coord)
    fprintf(fileID,'  %s     %s   %s   %s\n',num2str(NODE.Coord(i,1)), num2str(NODE.Coord(i,2)),num2str(NODE.Coord(i,3)),num2str(NODE.Coord(i,4)));
end
% Additional node for coupling
if NODE.adflag == 1 
  fprintf(fileID,'  %s     %s   %s   %s\n',num2str(NODE.Coord_ad(1,1)), num2str(NODE.Coord_ad(1,2)),num2str(NODE.Coord_ad(1,3)),num2str(NODE.Coord_ad(1,4)));
end
fprintf(fileID, '#  \n');

%========================================================================

% Write element connectivity information
fprintf(fileID, 'element.connectivity\n');

% If the partition type is parent, then write the super element
% connectivity first according to the partition number
if strcmp(part_type,'Parent')
    N_supelm = size(PARTITION.General.Supelm.node_num,1);
    
    for i =1:PARTITION.General.N
        for j = 1:N_supelm
            x = find(ELEMENT.(['Grp' num2str(j)]).Conn(:,1) == i);
            if ~isempty(x)    % the current superelement group contains current partition
                fprintf(fileID, '  grp.name = %s\n', GRP.(['Grp' num2str(j)]).name);
                fprintf(fileID, '  elm.name       nod.name\n');
                for k = 1:size(ELEMENT.(['Grp' num2str(j)]).Conn,2)
                    fprintf(fileID,'  %s',num2str(ELEMENT.(['Grp' num2str(j)]).Conn(x,k)));
                    if mod(k,6) == 0 && k~= size(ELEMENT.(['Grp' num2str(j)]).Conn,2)
                        fprintf(fileID,'  &\n');
                        fprintf(fileID,'          ');
                    elseif k == 1
                        fprintf(fileID,'      ');
                    end
                end
                fprintf(fileID,'\n');
                fprintf(fileID, '#  \n');
                break
            end
        end
    end
else
    N_supelm = 0;
end

% Write all other types of elements
for i =N_supelm+1:GRP.N
    fprintf(fileID, '  grp.name = %s\n', GRP.(['Grp' num2str(i)]).name);
    fprintf(fileID, '  elm.name       nod.name\n');
    for j = 1:ELEMENT.(['Grp' num2str(i)]).Nelm
        for k = 1:size(ELEMENT.(['Grp' num2str(i)]).Conn,2)
           fprintf(fileID,'  %s',num2str(ELEMENT.(['Grp' num2str(i)]).Conn(j,k)));
           if mod(k,6) == 0 && k~= size(ELEMENT.(['Grp' num2str(i)]).Conn,2)
               fprintf(fileID,'  &\n');
               fprintf(fileID,'          ');
           elseif k == 1
               fprintf(fileID,'      ');
           end
        end
        fprintf(fileID,'\n');
    end
    % Additional node for coupling
    fprintf(fileID, '#  \n');
end


%========================================================================

% Write coupled additional freedom information (Parent)
if strcmp(part_type,'Parent')
    fprintf(fileID, 'coupled.additional.freedoms\n');
    fprintf(fileID, '   elm.names       freedom.sets\n');
    % Due to an upper limit in the reading function, the coupling in single
    % specification has to be capped to 250 freedoms per partition， for now
    % assume the number of freedom needs to be coupled is between 301 and
    % 600
    for i = 1:size(DOFAD_COUPLE{1},1)
        fprintf(fileID, '     %s  %s     ',num2str(DOFAD_COUPLE{1}(i,1)),num2str(DOFAD_COUPLE{1}(i,2)));
        x = min(size(DOFAD_COUPLE{2}{i,1},2),250);
        for k = 1:x
            fprintf(fileID, '  %s',num2str(DOFAD_COUPLE{2}{i,1}(k)));
            if mod(k,6) == 0 && k~=x
                fprintf(fileID,'  &\n');
                fprintf(fileID,'          ');
            end
        end
        fprintf(fileID,'  &\n');
        fprintf(fileID,'          ');
        for k = 1:x
            fprintf(fileID, '  %s',num2str(DOFAD_COUPLE{2}{i,2}(k)));
            if mod(k,6) == 0 && k~=x
                fprintf(fileID,'  &\n');
                fprintf(fileID,'          ');
            end
        end
        fprintf(fileID, '\n');
        
        if size(DOFAD_COUPLE{2}{i,1},2)>250
            fprintf(fileID, '     %s  %s     ',num2str(DOFAD_COUPLE{1}(i,1)),num2str(DOFAD_COUPLE{1}(i,2)));
            for k = 251:size(DOFAD_COUPLE{2}{i,1},2)
                fprintf(fileID, '  %s',num2str(DOFAD_COUPLE{2}{i,1}(k)));
                if mod(k-250,6) == 0 && k~=size(DOFAD_COUPLE{2}{i,1},2)
                    fprintf(fileID,'  &\n');
                    fprintf(fileID,'          ');
                end
            end
            fprintf(fileID,'  &\n');
            fprintf(fileID,'          ');
            for k = 251:size(DOFAD_COUPLE{2}{i,1},2)
                fprintf(fileID, '  %s',num2str(DOFAD_COUPLE{2}{i,2}(k)));
                if mod(k-250,6) == 0 && k~=size(DOFAD_COUPLE{2}{i,1},2)
                    fprintf(fileID,'  &\n');
                    fprintf(fileID,'          ');
                end
            end
        end
        fprintf(fileID,'  \n');
        fprintf(fileID, '#  \n');
        
    end
end
%========================================================================

% Write partitioned boundary information (Child or parent with level 1 or greater)
if level > 0
    fprintf(fileID, 'partitioned.boundary\n');
    fprintf(fileID, 'parent.rank = %s\n', num2str(Parent_rank));
    fprintf(fileID, ' nod.name\n');
    for i = 1:size(DOFAD_BOUNDARY,1)
        fprintf(fileID, '   %s\n',num2str(DOFAD_BOUNDARY(i,1)));
    end
    fprintf(fileID, '#  \n');
    % fprintf(fileID, 'parent.rank = %s\n', num2str(rank-1));
    fprintf(fileID, ' elm.name   freedom\n');
    for i = 1:size(DOFAD_BOUNDARY,1)
        fprintf(fileID, '    %s     fa%s\n',num2str(DOFAD_BOUNDARY(i,2)),num2str(DOFAD_BOUNDARY(i,3)));
    end
    fprintf(fileID, '#  \n');
end

%========================================================================

% Write restraint information
if RES.N ~= 0
    fprintf(fileID, 'restraints\n');
    for i = 1:RES.N
        fprintf(fileID, ' direction = %s\n',RES.(['Grp' num2str(i)]).dir);
        fprintf(fileID, '  nod.name\n');
        
        switch RES.(['Grp' num2str(i)]).spec_method
            case 1
                for j = 1:length(RES.(['Grp' num2str(i)]).node)
                    fprintf(fileID, '  %s\n',num2str(RES.(['Grp' num2str(i)]).node(j)));
                end
            case 2
                for j = 1:RES.(['Grp' num2str(i)]).num_inc
                    fprintf(fileID, 'f   %s\n',num2str(RES.(['Grp' num2str(i)]).(['node_inc' num2str(j)])(1,1)));  % First line
                    for k = 2:size(RES.(['Grp' num2str(i)]).(['node_inc' num2str(j)]),1)
                        fprintf(fileID, 'r   %s   %s\n',num2str(RES.(['Grp' num2str(i)]).(['node_inc' num2str(j)])(k,1)),num2str(RES.(['Grp' num2str(i)]).(['node_inc' num2str(j)])(k,2)));
                    end
                end
            case 3
                % Doing both
                for j = 1:RES.(['Grp' num2str(i)]).num_inc
                    fprintf(fileID, 'f   %s\n',num2str(RES.(['Grp' num2str(i)]).(['node_inc' num2str(j)])(1,1)));  % First line
                    for k = 2:size(RES.(['Grp' num2str(i)]).(['node_inc' num2str(j)]),1)
                        fprintf(fileID, 'r   %s   %s\n',num2str(RES.(['Grp' num2str(i)]).(['node_inc' num2str(j)])(k,1)),num2str(RES.(['Grp' num2str(i)]).(['node_inc' num2str(j)])(k,2)));
                    end
                end
                for j = 1:length(RES.(['Grp' num2str(i)]).node)
                    fprintf(fileID, '  %s\n',num2str(RES.(['Grp' num2str(i)]).node(j)));
                end
        end
        fprintf(fileID, '#  \n');
    end
end


%========================================================================

% Write integration scheme information (only necessary in dynamic
% analysis)
if contains(Type_ana_text,'dynamic','IgnoreCase',true)
   fprintf(fileID, 'integration.scheme\n');
   fprintf(fileID, ' scheme = %s\n',INTSCHEME.scheme);
   for i = 1:INTSCHEME.para_N
       fprintf(fileID, ' %s = %s\n',INTSCHEME.para_name(i),num2str(INTSCHEME.para_val(i)));
   end
end
fprintf(fileID, '#  \n');

%========================================================================

% Write curve information (only necessary for time.history and dynamic
% loading)
if CURVE.flag == 1
   fprintf(fileID, 'linear.curve\n');
   fprintf(fileID, '  start.time = %s\n',CURVE.start_time);
   fprintf(fileID, '  crv.name = %s\n',CURVE.name);
   fprintf(fileID, '  time    load.factor\n');
   for i = 1:size(CURVE.xypoints,1)
       fprintf(fileID, ' %s     %s\n',num2str(CURVE.xypoints(i,1)),num2str(CURVE.xypoints(i,2)));
   end
end
fprintf(fileID, '#  \n');

%========================================================================

% Write loading information
if LOAD.N ~= 0
    fprintf(fileID, 'applied.loading\n');
    for i = 1:LOAD.N
        fprintf(fileID, '  %s\n',LOAD.(['Grp' num2str(i)]).name);
        fprintf(fileID, '   direction = %s\n',LOAD.(['Grp' num2str(i)]).dir);
        fprintf(fileID, '   type = %s\n',LOAD.(['Grp' num2str(i)]).type);
        if contains(LOAD.(['Grp' num2str(i)]).name,'dynamic') || contains(LOAD.(['Grp' num2str(i)]).name,'time.history')
            fprintf(fileID, '   crv.name = %s\n',LOAD.(['Grp' num2str(i)]).crv);
        end
        fprintf(fileID, '   value = %s\n',LOAD.(['Grp' num2str(i)]).value);
        fprintf(fileID, '   nod.name\n');
        
        switch LOAD.(['Grp' num2str(i)]).spec_method
            case 1
                for j = 1:length(LOAD.(['Grp' num2str(i)]).node)
                    fprintf(fileID, '   %s\n',num2str(LOAD.(['Grp' num2str(i)]).node(j)));
                end
            case 2
                for j = 1:LOAD.(['Grp' num2str(i)]).num_inc
                    fprintf(fileID, 'f    %s\n',num2str(LOAD.(['Grp' num2str(i)]).(['node_inc' num2str(j)])(1,1)));  % First line
                    for k = 2:size(LOAD.(['Grp' num2str(i)]).(['node_inc' num2str(j)]),1)
                        fprintf(fileID, 'r    %s   %s\n',num2str(LOAD.(['Grp' num2str(i)]).(['node_inc' num2str(j)])(k,1)),num2str(LOAD.(['Grp' num2str(i)]).(['node_inc' num2str(j)])(k,2)));
                    end
                end
            case 3
                % Doing both
                for j = 1:LOAD.(['Grp' num2str(i)]).num_inc
                    fprintf(fileID, 'f    %s\n',num2str(LOAD.(['Grp' num2str(i)]).(['node_inc' num2str(j)])(1,1)));  % First line
                    for k = 2:size(LOAD.(['Grp' num2str(i)]).(['node_inc' num2str(j)]),1)
                        fprintf(fileID, 'r    %s   %s\n',num2str(LOAD.(['Grp' num2str(i)]).(['node_inc' num2str(j)])(k,1)),num2str(LOAD.(['Grp' num2str(i)]).(['node_inc' num2str(j)])(k,2)));
                    end
                end
                for j = 1:length(LOAD.(['Grp' num2str(i)]).node)
                    fprintf(fileID, '   %s\n',num2str(LOAD.(['Grp' num2str(i)]).node(j)));
                end
        end
        fprintf(fileID, '#  \n');
    end
end

%========================================================================

% Write equilibrium stage
if level == 0
    fprintf(fileID, 'equilibrium.stages\n');
    fprintf(fileID, '  end.of.stage   steps\n');
    for i = 1:size(EQUI.xypoints,1)
        fprintf(fileID, '  %s      %s\n',num2str(EQUI.xypoints(i,1)),num2str(EQUI.xypoints(i,2)));
    end
    fprintf(fileID, '#  \n');
end

%========================================================================

% Write solver type

fprintf(fileID, 'solution.of.equations\n');
if strcmp(part_type,'Parent')
    fprintf(fileID, '  solver = %s\n',SOLVER.type_parent);
else
    fprintf(fileID,'  solver = %s\n',SOLVER.type);
end
fprintf(fileID, '#  \n');

%========================================================================

% Write iterative strategy
if strcmp(part_type,'Parent')
    fprintf(fileID, 'iterative.strategy\n');
    fprintf(fileID, ' number = %s\n',ITERSTRAT.number);
    fprintf(fileID, ' initial.reformation = %s\n',ITERSTRAT.reform);
    fprintf(fileID, ' step.reduction = %s\n',ITERSTRAT.reduction);
    fprintf(fileID, ' divergence.iteration = %s\n',ITERSTRAT.div);
    fprintf(fileID, ' maximum.convergence = %s\n',ITERSTRAT.maxconv);
    fprintf(fileID, '#  \n');
end

%========================================================================

% Write convergence criteria
fprintf(fileID, 'convergence.criteria\n');
fprintf(fileID, ' tolerance = %s\n',CONV.tol);
if strcmp('w',CONV.ref_type)
    fprintf(fileID, ' work.ref = %s\n',CONV.ref1);
elseif strcmp('fm',CONV.ref_type)
    fprintf(fileID, ' force.ref = %s\n',CONV.ref1);
    fprintf(fileID, ' moment.ref = %s\n',CONV.ref1);
else
    error('Input a valid refernce type')
end
fprintf(fileID, '#  \n');

%========================================================================

% Write output frequency (assume output stress by default)
fprintf(fileID, 'output\n');
fprintf(fileID, ' frequency %s \n',OUTPUT.freq);
fprintf(fileID, '#  \n');

%========================================================================

% end
fprintf(fileID, 'end');

%%  %%%%%%%%%%%%%%%%%%%%%%%%%%%% Close file %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Close the file
fclose(fileID);

end