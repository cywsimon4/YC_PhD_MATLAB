function [] = plotting_multi(HISTORY,PARAM,flag,setting1,setting2)

%%  %%%%%%%%%%%%%%%%%%%%%%%%%% Introduction %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% This subroutine plots figure for a batch of model runs, specification of
% flag in array "flag" is detailed below
% 1: plotting critical stress against l/t ratio at desired location
% 2: plotting stress and damage evolution for multiple cases at desired
% location
% 3: plotting bending moment against deformation for multiple cases

% Other input variables

%% %%%%%%%%%%%%%%%%%%%%% Setting default parameters %%%%%%%%%%%%%%%%%%%%%%%
% % if less flag is input than fill the remaining with zero
if length(flag) < 3
    for i = length(flag)+1:3
        flag(i) = 0;
    end
end
% 
% % set default parameters
% switch nargin
%     case 1 || 2
%         fprintf('need to input a flag')
%         return   % plot nothing by default
% 
%     case 3
%         setting1.ft = 1;
% 
%         setting2(1) = 1;
% 
%         setting3(1) = 1e-3;
%         setting3(2) = 1;
%         setting3(3) = 100;
% 
%     case 4
%         setting2(1) = 1;
% 
%         setting3(1) = 1e-3;
%         setting3(2) = 1;
%         setting3(3) = 100;
% 
%     case 5
%         setting3(1) = 1e-3;
%         setting3(2) = 1;
%         setting3(3) = 100;
% 
% end
% 
h = PARAM.h;
ft = PARAM.ft;
zrange = PARAM.zrange;

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% plotting 1 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if flag(1) == 1

    % For each run results, interpolate stress at desired location and then
    % extracts critical value

    z_interest = setting1.z_interest;
    stress_interest = zeros(length(HISTORY.(['l_t' num2str(1)]).a_1),1);
    critical_stress = zeros(HISTORY.n_test,length(z_interest));

    % Interpolate fields at desired depth
    for k = 1:HISTORY.n_test
        for j = 1:length(z_interest)
            for i = 1:length(HISTORY.(['l_t' num2str(k)]).a_1)
                stress_interest(i) = interp1(HISTORY.(['l_t' num2str(k)]).stress{i}(:,1),HISTORY.(['l_t' num2str(k)]).stress{i}(:,2),z_interest(j),'spline');
            end
            critical_stress(k,j) = max(stress_interest);
        end
    end

    % Empirical correction
    ratio_emp = 10.^(linspace(log10(HISTORY.ratio(1)),log10(HISTORY.ratio(end)),200));
    f_t_emp = @(x)(ft * (1 + 1.94592 * (1 + 0.5347 * x.^(-1.0095)).^ (-1)));

    numCurves = length(z_interest);
    cmap = gray(numCurves);
    styleline = {'k-*','k-x','k-s'};

    % 1. plot maximum stress against l/t ratio
    figure
    mainAxis = gca;

    for i = 1:length(z_interest)
        semilogx(HISTORY.ratio,critical_stress(:,i),styleline{i},'DisplayName',sprintf('$ \\overline{z} $ = %g mm', z_interest(i)),'LineWidth',1.2);
        hold (mainAxis,'on');
    end
    %plot(ratio_emp,f_t_emp(ratio_emp),'m-.','DisplayName','Empirical correction','LineWidth',2)
    semilogx(HISTORY.ratio,ft * ones(size(HISTORY.ratio)),'r--','DisplayName','homogeneous','LineWidth',1.2);
    grid(mainAxis,'on');
    xlabel(mainAxis,'$$ l_0/t_0 $$ [-]', 'Interpreter', 'latex','FontSize',14);
    ylabel(mainAxis,'$$\sigma_{x,\mathrm{crit}}$$ [MPa]', 'Interpreter', 'latex','FontSize',14);
    xlim(mainAxis,[HISTORY.ratio(end) HISTORY.ratio(1)]);
    ylim(mainAxis,[0,max(max(critical_stress))+3]);
    %title(mainAxis,"critical stress with different $$ l_0/t$$ ratio",'Interpreter', 'latex','FontSize',20);
    legend('Location','northwest','Interpreter','Latex')  % 


    frameAxis = axes('Position', mainAxis.Position, 'Color', 'none');
    %colormap(cmap);
    %clim([z_interest_str(1) z_interest_str(end)]);

    rectangle(frameAxis,'Position', [frameAxis.XLim(1), frameAxis.YLim(1), diff(frameAxis.XLim), diff(frameAxis.YLim)], ...
         'EdgeColor', 'k', 'LineWidth', 1);
    frameAxis.XTick = [];
    frameAxis.YTick = [];
    frameAxis.XColor = 'none';
    frameAxis.YColor = 'none';

    hold off

end

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% plotting 2 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if flag(2) == 1

    % For each run results, interpolate stress and damage at desired location


    z_interest = setting2.z_interest;    % To avoid congestion on plots, only one particular depth is assumed
    if length(z_interest) ~= 1
        error('only input one particular depth')
    end

    stress_interest = zeros(length(HISTORY.(['l_t' num2str(1)]).a_1),HISTORY.n_test);
    damage_interest = zeros(length(HISTORY.(['l_t' num2str(1)]).a_1),HISTORY.n_test);

    % Interpolate fields at desired depth
    for k = 1:HISTORY.n_test
        for i = 1:length(HISTORY.(['l_t' num2str(k)]).a_1)
            stress_interest(i,k) = interp1(HISTORY.(['l_t' num2str(k)]).stress{i}(:,1),HISTORY.(['l_t' num2str(k)]).stress{i}(:,2),z_interest,'spline');
            damage_interest(i,k) = interp1(HISTORY.(['l_t' num2str(k)]).damage{i}(:,1),HISTORY.(['l_t' num2str(k)]).damage{i}(:,2),z_interest,'spline');
        end
    end


    numCurves = HISTORY.n_test;
    cmap = jet(numCurves);

    % 2. plot stress profile against displacement
    figure
    for i = 1:HISTORY.n_test
        plot(HISTORY.(['l_t' num2str(i)]).a_1*2,stress_interest(:,i),'DisplayName',sprintf('l/t = %g', HISTORY.ratio(i)),'Color',cmap(i,:),'LineWidth',2.5);
        hold on;
    end
    plot(HISTORY.(['l_t' num2str(1)]).a_1*2,ft * ones(size(HISTORY.(['l_t' num2str(1)]).a_1)),'r--','DisplayName','critical','LineWidth',2);
    xlabel('$$u_{x,\mathrm{b}}$$ [mm]', 'Interpreter', 'latex');
    ylabel('$$\sigma_x$$ [MPa]', 'Interpreter', 'latex');
    title(['stress profile at z =', num2str(z_interest)]);
    legend; hold off

    % 2. plot damage profile against displacement
    figure
    for i = 1:HISTORY.n_test
        plot(HISTORY.(['l_t' num2str(i)]).a_1*2,damage_interest(:,i),'DisplayName',sprintf('l/t = %g', HISTORY.ratio(i)),'Color',cmap(i,:),'LineWidth',2.5);
        hold on;
    end
    xlabel('$$u_{x,\mathrm{b}}$$ [mm]', 'Interpreter', 'latex');
    ylabel('$$\phi$$ [-]', 'Interpreter', 'latex');
    title(['damage profile at z =', num2str(z_interest)]);
    legend; hold off

end

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% plotting 3 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Plot bending moment against bending deformation for various cases
if flag(3) == 1

    % Analytical estimation of bending moment capacity
    BM_ana = ft * h^3 / 12 / (h/2);   % Unit cross-sectional area is assumed

    numCurves = HISTORY.n_test;
    cmap = jet(numCurves);

    figure
    mainAxis = gca;
    for i = 1:HISTORY.n_test
        plot(HISTORY.(['l_t' num2str(i)]).a_1,HISTORY.(['l_t' num2str(i)]).BM,'DisplayName',sprintf('$$ l_0/t_0 $$ = %g', HISTORY.ratio(i)),'Color',cmap(i,:),'LineWidth',1.2);
        hold (mainAxis,'on');
    end
    plot(HISTORY.(['l_t' num2str(1)]).a_1,BM_ana * ones(size(HISTORY.(['l_t' num2str(1)]).a_1)),'r--','DisplayName','Elastic','LineWidth',1.2);
    xlabel('$$ \varepsilon_{b,max} $$  [-]','Interpreter', 'latex');
    ylabel('M [Nmm]','Interpreter', 'latex');
    %title('Bending moment against bending deformation for various l/t ratio');
    legend('Interpreter','Latex'); 
    grid(mainAxis,'on');

    frameAxis = axes('Position', mainAxis.Position, 'Color', 'none');
    %colormap(cmap);
    %clim([z_interest_str(1) z_interest_str(end)]);

    rectangle(frameAxis,'Position', [frameAxis.XLim(1), frameAxis.YLim(1), diff(frameAxis.XLim), diff(frameAxis.YLim)], ...
         'EdgeColor', 'k', 'LineWidth', 1);
    frameAxis.XTick = [];
    frameAxis.YTick = [];
    frameAxis.XColor = 'none';
    frameAxis.YColor = 'none';

    hold off

end