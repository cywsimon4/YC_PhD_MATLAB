function [] = plotting(HISTORY,PARAM,flag,setting1,setting2,setting3)

%%  %%%%%%%%%%%%%%%%%%%%%%%%%% Introduction %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% This subroutine plots figure for a specific run of ode, specification of
% flag in array "flag" is detailed below
% 1: stress and damage at critical location
% 2: stress and damage profile evolution
% 3: contour at specific position
% 4: evolution of centroidal strain against displacement
% 5: resultant force against internal deformation

% Other input variables
% setting2: parameters used for profile evolution plotting, containing: 1)
% frequency of plotting
% setting3: parameters used for contour plotting, containing: 1) desired
% displacement a; 2) type of field plotted; 3) amplification factor

%% %%%%%%%%%%%%%%%%%%%%% Setting default parameters %%%%%%%%%%%%%%%%%%%%%%%
% if less flag is input than fill the remaining with zero
if length(flag) < 5
    for i = length(flag)+1:5
        flag(i) = 0;
    end
end

% set default parameters
switch nargin
    case 1 || 2
        fprintf('need to input a flag')
        return   % plot nothing by default

    case 3

        setting2(1) = 1;

        setting3(1) = 1e-3;
        setting3(2) = 1;
        setting3(3) = 100;

    case 4
        setting2(1) = 1;

        setting3(1) = 1e-3;
        setting3(2) = 1;
        setting3(3) = 100;

    case 5
        setting3(1) = 1e-3;
        setting3(2) = 1;
        setting3(3) = 100;

end

h = PARAM.h;
zrange = PARAM.zrange;

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% plotting 1 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if flag(1) == 1

    ft = PARAM.ft;
    z_interest_str = setting1.z_interest_str;
    z_interest_dam = setting1.z_interest_dam;

    damage_interest = zeros(length(HISTORY.a_1),length(z_interest_dam));
    stress_interest = zeros(length(HISTORY.a_1),length(z_interest_str));
    strain_interest = zeros(length(HISTORY.a_1),length(z_interest_str));

    % Interpolate fields at desired depth
    for i = 1:length(HISTORY.a_1)
        for j = 1:length(z_interest_str)
            stress_interest(i,j) = interp1(HISTORY.stress{i}(:,1),HISTORY.stress{i}(:,2),z_interest_str(j),'spline');
            strain_interest(i,j) = interp1(HISTORY.strain{i}(:,1),HISTORY.strain{i}(:,2),z_interest_str(j),'spline');
        end

        for j = 1:length(z_interest_dam)
            damage_interest(i,j) = interp1(HISTORY.damage{i}(:,1),HISTORY.damage{i}(:,2),z_interest_dam(j),'spline');
        end

    end

    numCurves = length(z_interest_str);
    cmap = jet(numCurves);

    % 1. plot stress at desired location
    % against strain
    figure
    mainAxis = gca;
    hold (mainAxis,'on');
    for i = 1:length(z_interest_str)
        plot(strain_interest(:,i),stress_interest(:,i),'Color',cmap(i,:),'DisplayName',sprintf('$ \\overline{z} $ = %g mm', z_interest_str(i)),'LineWidth',1.2);
%         hold on;
    end
    plot(strain_interest(:,1),ft * ones(size(stress_interest(:,1))),'r--','DisplayName','homogeneous','LineWidth',1.2);
    xlabel(mainAxis,'$$ \varepsilon_x $$ [-]','Interpreter', 'latex','FontSize',14);
    ylabel(mainAxis,'$$ \sigma_x $$ [MPa]','Interpreter', 'latex','FontSize',14);
    title(mainAxis,['$$ l_0/t_0 $$ =', num2str(HISTORY.ratio)],'Interpreter', 'latex','FontSize',20); %stress-strain relationship at specfic depth, 
    grid (mainAxis,'on');
    legend('Interpreter', 'latex','FontSize',12)
    ylim(mainAxis,[0,25]);
    xlim(mainAxis,[0,2e-3]);
    frameAxis = axes('Position', mainAxis.Position, 'Color', 'none');
    colormap(cmap);
    clim([z_interest_str(1) z_interest_str(end)]);

    rectangle(frameAxis,'Position', [frameAxis.XLim(1), frameAxis.YLim(1), diff(frameAxis.XLim), diff(frameAxis.YLim)], ...
         'EdgeColor', 'k', 'LineWidth', 1);
    frameAxis.XTick = [];
    frameAxis.YTick = [];
    frameAxis.XColor = 'none';
    frameAxis.YColor = 'none';

    hold off

    % against horizontal displacement

    figure
    mainAxis = gca;
    hold (mainAxis,'on');
    grid (mainAxis,'on');

    for i = 1:length(z_interest_str)
        plot(2*HISTORY.a_1,stress_interest(:,i),'Color',cmap(i,:),'DisplayName',sprintf('$ \\overline{z} $ = %g mm', z_interest_str(i)),'LineWidth',1.2);
    end
    plot(2*HISTORY.a_1,ft * ones(size(stress_interest(:,1))),'r--','DisplayName','homogeneous','LineWidth',1.2);
    xlabel(mainAxis,'$$ \varepsilon_{b,max} $$ [-]','Interpreter', 'latex','FontSize',14);
    ylabel(mainAxis,'$$ \sigma_x$$ [MPa]','Interpreter', 'latex','FontSize',14);
    title(mainAxis,['$$ l_0/t_0 $$ =', num2str(HISTORY.ratio)],'Interpreter', 'latex','FontSize',20);  % stress-displacement relationship at specfic depth, 
    legend('Interpreter', 'latex','FontSize',12)
    ylim(mainAxis,[-25,25]);

    frameAxis = axes('Position', mainAxis.Position, 'Color', 'none');
    colormap(cmap);
    clim([z_interest_str(1) z_interest_str(end)]);

    rectangle(frameAxis,'Position', [frameAxis.XLim(1), frameAxis.YLim(1), diff(frameAxis.XLim), diff(frameAxis.YLim)], ...
         'EdgeColor', 'k', 'LineWidth', 1);
    frameAxis.XTick = [];
    frameAxis.YTick = [];
    frameAxis.XColor = 'none';
    frameAxis.YColor = 'none';
    hold off

    % 2. plot damage profile at top and bottom of element
%     figure
%     hold on
%     for i = 1:length(z_interest_dam)
%         plot(HISTORY.a_1,damage_interest(:,i),'DisplayName',sprintf('z = %g', z_interest_dam(i)),'LineWidth',1.5);
%         hold on;
%     end
%     xlabel('a [mm]');
%     ylabel('\phi [-]');
%     title(['damage evolution at specfic depth, l/t =',num2str(HISTORY.ratio)]);
%     legend

end

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% plotting 2 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if flag(2) == 1

    freq = setting2;    % plot every output by default

    % 3. plot evolution of stress profile against depth
    % Define color map to make color of evolution gradually chaning
    numCurves = length(HISTORY.stress);
    cmap = jet(numCurves);

    figure
    mainAxis = gca;
    hold (mainAxis,'on');
    grid(mainAxis,'on');
    for i = 1:length(HISTORY.stress)
        if mod(i-1,freq) == 0 || i == length(HISTORY.stress)
            plot(HISTORY.stress{i}(:,2),HISTORY.stress{i}(:,1),'Color',cmap(i,:),'LineWidth',1.2);
        end
    end
    xlabel(mainAxis,'$$ \sigma_x $$ [MPa]','Interpreter', 'latex','FontSize',14);
    ylabel(mainAxis,'$ \overline{z} $ [mm]','Interpreter', 'latex','FontSize',14)
    xlim(mainAxis,[-20,15]);
    %title(mainAxis,['$$ l_0/t_0 $$ =', num2str(HISTORY.ratio)],'Interpreter', 'latex','FontSize',20)    %Stress Profile Evolution
    frameAxis = axes('Position', mainAxis.Position, 'Color', 'none');
    %colorbar;
    colormap(cmap);
    clim([HISTORY.a_1(1) HISTORY.a_1(end)]);
    
    % Adjust the main plot axis position to make room for the frame
    % Add a rectangle frame around the plot
    rectangle(frameAxis,'Position', [frameAxis.XLim(1), frameAxis.YLim(1), diff(frameAxis.XLim), diff(frameAxis.YLim)], ...
         'EdgeColor', 'k', 'LineWidth', 1);
    frameAxis.XTick = [];
    frameAxis.YTick = [];
    frameAxis.XColor = 'none';
    frameAxis.YColor = 'none';

%     set(mainAxis, 'Color', 'none');
%     uistack(mainAxis, 'top');

    hold off;

    % 4. plot evolution of strain profile against depth
    figure
    mainAxis = gca;
    hold (mainAxis,'on');
    grid(mainAxis,'on');
    for i = 1:length(HISTORY.strain)
        if mod(i-1,freq) == 0 || i == length(HISTORY.strain)
            plot(HISTORY.strain{i}(:,2),HISTORY.strain{i}(:,1),'Color',cmap(i,:),'LineWidth',1.2);
        end
    end
    xlabel('$$ \varepsilon_x $$ [-]','Interpreter', 'latex','FontSize',14);
    ylabel(mainAxis,'$ \overline{z} $ [mm]','Interpreter', 'latex','FontSize',14);
    title(mainAxis,['$$ l_0/t_0 $$ =', num2str(HISTORY.ratio)],'Interpreter', 'latex','FontSize',20)  %Strain Profile Evolution,
    frameAxis = axes('Position', mainAxis.Position, 'Color', 'none');
    %colorbar;
    colormap(cmap);
    clim([HISTORY.a_1(1) HISTORY.a_1(end)]);

    % Add a rectangle frame around the plot
    rectangle(frameAxis,'Position', [frameAxis.XLim(1), frameAxis.YLim(1), diff(frameAxis.XLim), diff(frameAxis.YLim)], ...
         'EdgeColor', 'k', 'LineWidth', 1);
    frameAxis.XTick = [];
    frameAxis.YTick = [];
    frameAxis.XColor = 'none';
    frameAxis.YColor = 'none';


    % 5. plot evolution of damage profile against depth
    figure
    mainAxis = gca;
    hold (mainAxis,'on');
    grid(mainAxis,'on');
    for i = 1:length(HISTORY.stress)
        if mod(i-1,freq) == 0 || i == length(HISTORY.stress)
            plot(HISTORY.damage{i}(:,2),HISTORY.damage{i}(:,1),'Color',cmap(i,:),'LineWidth',1.2)
        end
    end
    
    xlabel(mainAxis,'$$ \phi [-] $$','Interpreter', 'latex','FontSize',14);
    ylabel(mainAxis,'$ \overline{z} $ [mm]','Interpreter', 'latex','FontSize',14);
    title(mainAxis,['$$ l_0/t_0 $$ =',num2str(HISTORY.ratio)],'Interpreter', 'latex','FontSize',20)  %Damage Profile Evolution,
    frameAxis = axes('Position', mainAxis.Position, 'Color', 'none');
    %colorbar;
    colormap(cmap);
    clim([HISTORY.a_1(1) HISTORY.a_1(end)]);

    % Add a rectangle frame around the plot
    rectangle(frameAxis,'Position', [frameAxis.XLim(1), frameAxis.YLim(1), diff(frameAxis.XLim), diff(frameAxis.YLim)], ...
         'EdgeColor', 'k', 'LineWidth', 1);
    frameAxis.XTick = [];
    frameAxis.YTick = [];
    frameAxis.XColor = 'none';
    frameAxis.YColor = 'none';

end

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% plotting 3 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if flag(3) == 1
    % 5. Contour
    % reshape the desired field into a 2-dimensional quantity

    % setting
    a_interest = setting3(1);
    field_type = setting3(2);          % 1: stress profile;  2: damage profile
    amp = setting3(3);                % amplification of horizontal displacement

    % plot
    % Locate two indices surrounding a_interest
    index_low = find(HISTORY.a_1<=a_interest,1,'last');
    index_up = find(HISTORY.a_1>=a_interest,1);
    zq = linspace(zrange(1), zrange(2), 100); % New y coordinates

    if index_up == index_low % the output contains the desired displacement
        fprintf('desired displacement is contained in output');
        switch field_type
            case 1
                field_interest = interp1(HISTORY.stress{index_low}(:,1),HISTORY.stress{index_low}(:,2),zq,'spline');

            case 2
                field_interest = interp1(HISTORY.damage{index_low}(:,1),HISTORY.damage{index_low}(:,2),zq,'spline');
        end
    else
        fprintf('An interpolation is required for contour at desired displacement')
        switch field_type
            case 1
                field_interest_low = interp1(HISTORY.stress{index_low}(:,1),HISTORY.stress{index_low}(:,2),zq,'spline');
                field_interest_up = interp1(HISTORY.stress{index_up}(:,1),HISTORY.stress{index_up}(:,2),zq,'spline');
            case 2
                field_interest_low = interp1(HISTORY.damage{index_low}(:,1),HISTORY.damage{index_low}(:,2),zq,'spline');
                field_interest_up = interp1(HISTORY.damage{index_up}(:,1),HISTORY.damage{index_up}(:,2),zq,'spline');
        end
        field_interest = zeros(length(zq),1);
        for i = 1:length(zq)
            aq = [HISTORY.a_1(index_low) HISTORY.a_1(index_up)];
            yq = [field_interest_low(i) field_interest_up(i)];
            field_interest(i) = interp1(aq,yq,a_interest,'spline');
            if field_type == 2
                field_interest(i) = max(min(field_interest(i),1),0);  % Constrain damage to 0 and 1
            end
        end
    end

    % New grid for interpolation
    xq = linspace(-0.5-a_interest*amp, 0.5+a_interest*amp, 100); % New x coordinates
    [Xq, Zq] = meshgrid(xq, zq); % New 2D grid
    field2D = repmat(field_interest,1,100);
    c = h / 2 / a_interest / amp;
    for i = 1:length(zq)
        state = xq<(zq(i)-0.5*c)/c |  xq>(zq(i)-0.5*c)/-c;
        field2D(i,state) = NaN;
    end

    % plot contour
    figure
    contourf(Xq,Zq,field2D);
    ylim([zrange(1),zrange(2)]);
    colormap(jet);
    colorbar;

end

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% plotting 4 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Plot evolution of centroidal strain and position of neutral axis against bending deformation a
if flag(4) == 1

    figure
    plot(HISTORY.a_1,HISTORY.eps_c,'r-','LineWidth',2);
    xlabel('a [mm]');
    ylabel('\epsilon_c [-]');
    title(['Evolution of centroidal strain, l/t =', num2str(HISTORY.ratio)]);
    hold off

    figure
    plot(HISTORY.a_1,HISTORY.z_0str,'r-','LineWidth',2);
    xlabel('a [mm]');
    ylabel('Position of neutral axis [mm]');
    ylim(zrange);
    title(['Evolution of neutral axis position, l/t =', num2str(HISTORY.ratio)]);
    hold off
end

%% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% plotting 5 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Plot evolution of internal resultant force against strains
if flag(5) == 1

    figure
    plot(HISTORY.eps_c,HISTORY.axialF,'r.-','LineWidth',1.7);
    xlabel('\epsilon_c [-]');
    ylabel('F [N]');
    title(['Axial force against axial strain, l/t =', num2str(HISTORY.ratio)]);
    hold off

    figure
    plot(HISTORY.a_1,HISTORY.BM,'r*-','LineWidth',1.7);
    xlabel('a [mm]');
    ylabel('M [Nmm]');
    title(['Bending moment against bending deformation, l/t =', num2str(HISTORY.ratio)]);
    hold off
end