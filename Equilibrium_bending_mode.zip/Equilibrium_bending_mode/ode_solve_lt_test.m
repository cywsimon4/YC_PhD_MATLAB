clc;
clear;
close all;

%%  %%%%%%%%%%%%%%%%%%%%%%%%% Introduction %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% This main file runs a batch of odes for different length
% scale-to-thickness ratio to establish the influence of that on the
% strength

%%  %%%%%%%%%%%%%%%%%%%%%% Parameter definition %%%%%%%%%%%%%%%%%%%%%%%%%%%
% Parameters
% Material parameters and deformation
E = 1e5;
ft = 10;
h = 1;
deg = @(phi)(10^-3 * ((1-phi).^3 - (1-phi).^2) + 3 * (1-phi).^2 - 2*(1-phi).^3);  % Cubic degradation function

% Variable parameter
a_range = linspace(0,0.001,200);     % horizontal displacement at bottom of the element (half)
ratio = [1 1/10 1/100 1/1000];
l0_range = ratio * h;
Gc_range = ft^2*250^2/27^2/30/E.*l0_range;  % estimation of fracture energy based on homogeneous expression

% Parameters related to BVP definition and zero axial force constraint
phi_0 = 0; % Boundary condition at z = -2/h
phi_L = 0; % Boundary condition at z = h
% sympref('HeavisideAtOrigin',1);
bl = -h/2; bu = h/2;         % Upper and lower bound of the domain
zq = linspace(bl, bu, 200);
opt.interpo_points = 'bvp4c';   


% Numerical parameters related to iterative solving procedure
eps_co = 0;
eps_cn = inf;
relerror = inf;
tol = 1e-4;                       
iter_max = 100;
iter = 0;

% Output setting
freq = 1;                         % frequency of output for checking profile evolution

% Initialisation
HISTORY.n_test = length(ratio);
HISTORY.ratio = ratio;
for i = 1:length(l0_range)
    HISTORY.(['l_t' num2str(i)]).ratio = ratio(i);
    HISTORY.(['l_t' num2str(i)]).stress = cell(1);
    HISTORY.(['l_t' num2str(i)]).damage = cell(1);
    HISTORY.(['l_t' num2str(i)]).a_1 = a_range;
    HISTORY.(['l_t' num2str(i)]).strain = cell(1);
    HISTORY.(['l_t' num2str(i)]).eps_c = []; 
    % Iteration and relative error would not be recorded
end

% Initial guess to BVP solution
solinit = bvpinit(linspace(-h/2, h/2, 200), [1, 0]);

%%  %%%%%%%%%%%%%%%%%%%%%%%%% Solving odes %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for j = 1:length(l0_range)
    l0 = l0_range(j);
    Gc = Gc_range(j);
    eps_hist = [NaN NaN NaN];         % History recording previous three iteration results

    for i = 1:length(a_range)

        a = a_range(i);

        % Initialisation of numerical parameter
        % Note eps_co is set to be the convergent result at last deformation
        % step
        relerror = inf;
        iter = 0;

        % Repeat the process until relative difference of new and old estimate of centroidal strain
        % is close to 0 or maximum iteration is reached.
        while relerror > tol && iter < iter_max

            % For fixed centroidal strains solve for the BVP
            sol = bvp4c(@(z,y)odefcn(z, y,E,l0,Gc,a,h,eps_co), ...
                @bcfcn, solinit);

            % Extract the solution
            z = sol.x;
            phi = sol.y(1, :);

            % Interpolate at the fixed grid (optional)
            if strcmp(opt.interpo_points,'fixed')
                phi_q = interp1(z,phi,zq,'spline');
            elseif strcmp(opt.interpo_points,'bvp4c')
                phi_q = phi;
                zq = z;
            else
                error('Input a valid interpolation point option');
            end

            % From fixed damage field, solve for centroidal axial strain
            % Create interpolating function including constant part of the function
            % and coefficients
            eps_b = 4 * a * (-zq / h);      % Bending part of strain
            aq = zeros(size((zq))); bq = zeros(size(zq));  % Value of coefficients at different depth

            for m = 1:length(zq)
                % Note the coefficients are determined based on the old centroidal strain value as approximation
                bq(m) = E * deg(phi_q(m) * heaviside(eps_b(m)+eps_co)) * eps_b(m);
                aq(m) = E * deg(phi_q(m) * heaviside(eps_b(m)+eps_co));
            end

            a_interp = @(z) interp1(zq,aq,z,'spline');
            b_interp = @(z) interp1(zq,bq,z,'spline');

            % Solve for centroidal strain that satisfies the constraint
            eps_cn = fzero(@(eps_c) axialres(eps_c,bl,bu,a_interp,b_interp), eps_co);

            % Detect whether oscillation of solution occurs
            if min(abs((eps_cn-eps_hist(1:end-1))./eps_hist(1:end-1))) <= 1e-8
                eps_co = eps_cn;
                iter = iter + 1;
                % fprintf('Oscillation in solution occurs at step %g, l/t = %g \n', i,ratio(j))
                break
            end

            % Calculate norm
            relerror = abs((eps_cn - eps_co)/eps_co);

            % Update counter, strain and historic strain
            if iter >= 10
                eps_hist(1) = eps_hist(2);
                eps_hist(2) = eps_hist(3);
                eps_hist(3) = eps_cn;
            end
            eps_co = eps_cn;
            iter = iter+1;
        end

        % If iteration reaches maximum without convergence then exit and report
        % error
        if iter == iter_max && eps_cn >= 1e-16
            error('Failure in solving: Convergence is not achieved within maximum iteration');
        end

        % Calculating stresses and store the results
        strain = eps_cn + 4 * a .* (-zq/h);
        stress = E * deg(phi_q.*heaviside(strain)) .* strain;

        HISTORY.(['l_t' num2str(j)]).stress{end+1,1} = [zq' stress'];
        HISTORY.(['l_t' num2str(j)]).strain{end+1,1} = [zq' strain'];
        HISTORY.(['l_t' num2str(j)]).damage{end+1,1} = [zq' phi_q'];
        HISTORY.(['l_t' num2str(j)]).eps_c(end+1) = eps_cn;

    end

    % remove first cell
    HISTORY.(['l_t' num2str(j)]).stress(1) = [];
    HISTORY.(['l_t' num2str(j)]).damage(1) = [];
    HISTORY.(['l_t' num2str(j)]).strain(1) = [];
end

%%  %%%%%%%%%%%%%%%%%%%%%% data post-processing %%%%%%%%%%%%%%%%%%%%%%%%%%%
flag = 1;
Param.ft = ft;
Param.zrange = [-h/2 h/2];
Param.h = h;
for i = 1:length(l0_range)
   HISTORY.(['l_t' num2str(i)]) = post_processor_singlerun(HISTORY.(['l_t' num2str(i)]),Param,flag);
end

%%  %%%%%%%%%%%%%%%%%%%%%%%%%%%%% plotting %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Define parameter
flag = [0 0 0];
% 1: stress and damage at critical location
% 2: stress and damage profile evolution
% 3: contour at specific position
% 4: resultant force against internal deformation (not yet construct)

setting1.z_interest_str = linspace(-h/2,0,6);   % Specific depth that stress profile is plotted
setting1.z_interest_dam = [-h/2 0];          % Specific depth that damage profile is plotted
setting3 = [5e-4 1 500];
% Entry 1: strain level that field contour is plotted
% Entry 2: 1) stress field, 2) damage field
% Entry 3: Amplification factor for displacement

% General parameters
Param_plot.ft = ft;
Param_plot.zrange = [-h/2 h/2];
Param_plot.h = h;

% Call function for plotting single run results
for i = 1:length(l0_range)
   plotting(HISTORY.(['l_t' num2str(i)]),Param_plot,flag,setting1,freq,setting3)
end

% Call function for handling multiple run results
setting1.z_interest = [-h/2 -h/4 0];
setting2.z_interest = -h/2;
flag = [1 1 1];
plotting_multi(HISTORY,Param_plot,flag,setting1,setting2)


%%  %%%%%%%%%%%%%%%%%% Defining differential equations %%%%%%%%%%%%%%%%%%%%
% Define the ODE as a system of first-order ODEs
function dydz = odefcn(z, y,E,l0,Gc,a,h,eps_co)

    phi = y(1);
    dphidz = y(2);
    eps = 4 * a * (-z / h) + eps_co;

    % Quadratic degradation
    %d2phidz2 = (Gc * phi / l0 - 16 * E * a^2 * z^2 * (1 - phi) / h^2) / (Gc * l0);

    % Cubic degradation
    d2phidz2 = (Gc * phi / l0 + E *eps^2 * heaviside(eps) /2 * (10^(-3) *(-3 * (1 - phi)^2 + 2*(1-phi)) - 6 * (1-phi) + 6 * (1-phi)^2)) / (Gc * l0);

    dydz = [dphidz; d2phidz2];
end

% Define the boundary conditions
function res = bcfcn(ya, yb)
    res = [ya(2); % phi(0) = phi0
           yb(2)]; % phi(L) = phiL
end

% Define the residual function for zero axial force constriant
function R = axialres(eps_c,bl,bu,a_interp,b_interp)

    % Use the interpolating function for the integrand
    integrandFunction = @(z) a_interp(z);
    % Perform the integration for coefficient a
    a = integral(integrandFunction, bl, bu);
     
    % Use the interpolating function for the integrand
    integrandFunction = @(z) b_interp(z);
    % Perform the integration for coefficient a
    b = integral(integrandFunction, bl, bu);
    
    % Calculate R(eps_c)
    R = a * eps_c + b;
end