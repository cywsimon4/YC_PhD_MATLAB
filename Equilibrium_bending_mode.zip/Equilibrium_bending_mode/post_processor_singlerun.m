function [HISTORY] = post_processor_singlerun(HISTORY,PARAM,flag)

%%  %%%%%%%%%%%%%%%%%%%%%%%%%% Introduction %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% This subroutine acts as a post-processor by fulfilling some specific
% taskes
% 1: resultant stress computation (axial and bending moment)


% Other input variables

h = PARAM.h;
zrange = PARAM.zrange;

%%  %%%%%%%%%%%%%%%%%%%% Resultant force calculation %%%%%%%%%%%%%%%%%%%%%%
% 1. resultant force calculation
% Interpolate the stresses at desired point and integrate by numerical
% rules (assuming unit width)

if flag(1) == 1
    zq = linspace(zrange(1), zrange(2), 1000); % New y coordinates
    HISTORY.axialF = zeros(length(HISTORY.a_1),1);

    for i = 1:length(HISTORY.a_1)
        sigma_xq = interp1(HISTORY.stress{i}(:,1),HISTORY.stress{i}(:,2),zq,'spline');

        % Axial force
        HISTORY.axialF(i) = trapz(zq,sigma_xq);

        % Bending moment
        % Locate the position with zero strain first
        if i == 1
            HISTORY.z_0str(i) = 0;
        else
            HISTORY.z_0str(i) = interp1(HISTORY.strain{i}(:,2),HISTORY.strain{i}(:,1),0,'spline');
        end

        % Compute bending moment based on that position
        HISTORY.BM(i) = trapz(zq,sigma_xq.*(HISTORY.z_0str(i)-zq));

    end
end